export type Language = 'mr' | 'hi' | 'en';

export type NetworkMode = 'online' | 'slow-3g' | 'offline';

export interface Doctor {
  id: string;
  name: string;
  specialty: string;
  qualification: string;
  availableDays: string;
  availableToday: boolean;
  avatarUrl?: string;
}

export interface PHCFacility {
  id: string;
  name: string;
  nameMr: string;
  nameHi: string;
  type: 'PHC' | 'CHC' | 'Sub-Center' | 'Rural Hospital';
  district: string;
  districtMr: string;
  taluka: string;
  distanceKm: number;
  operatingHours: string;
  contactNumber: string;
  currentWaitMinutes: number;
  cleanlinessScore: number; // 1 to 5
  totalBeds: number;
  availableBeds: number;
  deliveryFacility24x7: boolean;
  ambulanceAvailable: boolean;
  labTestsCount: number;
  address: string;
  doctors: Doctor[];
  coordinates: { lat: number; lng: number };
}

export interface MedicineItem {
  id: string;
  genericName: string;
  brandName: string;
  nameMr: string;
  nameHi: string;
  category: 'Antibiotic' | 'Analgesic' | 'Maternal Health' | 'Chronic Care' | 'Vaccine/Serum' | 'Emergency';
  strength: string;
  dosageForm: 'Tablet' | 'Syrup' | 'Injection' | 'Vial' | 'Sachet';
  stockStatus: 'In Stock' | 'Low Stock' | 'Out of Stock';
  availableUnits: number;
  phcLocation: string;
  district: string;
  expiryDate: string;
  batchNumber: string;
  isFreeGovtSupply: boolean;
}

export interface TeleconsultationBooking {
  id: string;
  patientName: string;
  age: number;
  gender: 'Female' | 'Male' | 'Other';
  category: 'General' | 'Pregnant Mother (ANC)' | 'Child Under 5' | 'Elderly / Chronic';
  phone: string;
  village: string;
  district: string;
  preferredLanguage: Language;
  symptoms: string[];
  severity: 'Mild' | 'Moderate' | 'Severe / Emergency';
  vitals?: {
    bp?: string;
    pulse?: number;
    spo2?: number;
    temperature?: number;
  };
  clinicalNotes?: string;
  prescriptionSlipAttached?: boolean;
  status: 'Waiting' | 'In Consultation' | 'Prescription Issued' | 'Referred';
  createdAt: string;
}

export interface GrievanceReport {
  id: string;
  trackingId: string;
  facilityId: string;
  facilityName: string;
  district: string;
  cleanlinessRating: number;
  doctorAvailabilityRating: number;
  medicineSupplyRating: number;
  overallRating: number;
  issues: string[];
  comments: string;
  citizenPhone: string;
  citizenName: string;
  status: 'Under Investigation' | 'Action Initiated' | 'Resolved' | 'Closed';
  createdAt: string;
  resolutionNote?: string;
}

export interface AshaPatientRecord {
  id: string;
  patientName: string;
  village: string;
  recordType: 'ANC (Maternal)' | 'Child Immunization' | 'SAM/MAM Nutrition' | 'Fever/Malaria Survey';
  details: string;
  visitDate: string;
  synced: boolean;
  timestamp: number;
}

export interface RegionalAlert {
  id: string;
  district: string;
  type: 'Outbreak Warning' | 'Supply Shortage' | 'Weather/Monsoon Alert' | 'Immunization Drive';
  title: string;
  titleMr: string;
  description: string;
  severity: 'High' | 'Medium' | 'Informational';
  date: string;
}
