import React, { createContext, useContext, useState, useEffect } from 'react';
import { Language, NetworkMode, PHCFacility, MedicineItem, GrievanceReport, AshaPatientRecord, TeleconsultationBooking } from '../types';
import { translations } from '../data/translations';
import { MOCK_FACILITIES, MOCK_MEDICINES, INITIAL_GRIEVANCES, INITIAL_ASHA_RECORDS } from '../data/mockData';

interface AppContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: typeof translations['mr'];
  networkMode: NetworkMode;
  setNetworkMode: (mode: NetworkMode) => void;
  dataSaver: boolean;
  setDataSaver: (val: boolean) => void;
  textSize: 'normal' | 'large' | 'xlarge';
  setTextSize: (size: 'normal' | 'large' | 'xlarge') => void;
  activeTab: 'home' | 'locator' | 'telemed' | 'medicines' | 'grievance' | 'asha-admin';
  setActiveTab: (tab: 'home' | 'locator' | 'telemed' | 'medicines' | 'grievance' | 'asha-admin') => void;
  
  facilities: PHCFacility[];
  selectedFacility: PHCFacility | null;
  setSelectedFacility: (fac: PHCFacility | null) => void;
  
  medicines: MedicineItem[];
  medicineSearch: string;
  setMedicineSearch: (query: string) => void;
  
  grievances: GrievanceReport[];
  addGrievance: (g: Omit<GrievanceReport, 'id' | 'trackingId' | 'status' | 'createdAt'>) => string;
  getGrievanceByTrackingId: (id: string) => GrievanceReport | undefined;
  
  ashaRecords: AshaPatientRecord[];
  addAshaRecord: (rec: Omit<AshaPatientRecord, 'id' | 'synced' | 'timestamp'>) => void;
  syncPendingRecords: () => Promise<number>;
  pendingSyncCount: number;

  consultations: TeleconsultationBooking[];
  activeConsultation: TeleconsultationBooking | null;
  setActiveConsultation: (c: TeleconsultationBooking | null) => void;
  bookConsultation: (booking: Omit<TeleconsultationBooking, 'id' | 'status' | 'createdAt'>) => TeleconsultationBooking;

  alertMessage: string | null;
  setAlertMessage: (msg: string | null) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const LOCAL_STORAGE_GRIEVANCES = 'nirmal_swasthya_grievances_v1';
const LOCAL_STORAGE_ASHA = 'nirmal_swasthya_asha_records_v1';

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('mr');
  const [networkMode, setNetworkMode] = useState<NetworkMode>('online');
  const [dataSaver, setDataSaver] = useState<boolean>(false);
  const [textSize, setTextSize] = useState<'normal' | 'large' | 'xlarge'>('normal');
  const [activeTab, setActiveTab] = useState<'home' | 'locator' | 'telemed' | 'medicines' | 'grievance' | 'asha-admin'>('home');
  const [selectedFacility, setSelectedFacility] = useState<PHCFacility | null>(null);
  const [medicineSearch, setMedicineSearch] = useState<string>('');
  const [alertMessage, setAlertMessage] = useState<string | null>(null);

  // Facilities & Medicines
  const [facilities] = useState<PHCFacility[]>(MOCK_FACILITIES);
  const [medicines] = useState<MedicineItem[]>(MOCK_MEDICINES);

  // Grievances loaded with localStorage fallback
  const [grievances, setGrievances] = useState<GrievanceReport[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_GRIEVANCES);
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return INITIAL_GRIEVANCES;
  });

  // ASHA records with offline persistence
  const [ashaRecords, setAshaRecords] = useState<AshaPatientRecord[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_ASHA);
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return INITIAL_ASHA_RECORDS;
  });

  // Consultations state
  const [consultations, setConsultations] = useState<TeleconsultationBooking[]>([]);
  const [activeConsultation, setActiveConsultation] = useState<TeleconsultationBooking | null>(null);

  // Sync to local storage
  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_GRIEVANCES, JSON.stringify(grievances));
    } catch (e) {
      console.warn('Storage error', e);
    }
  }, [grievances]);

  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_ASHA, JSON.stringify(ashaRecords));
    } catch (e) {
      console.warn('Storage error', e);
    }
  }, [ashaRecords]);

  // Handle system online/offline events
  useEffect(() => {
    const handleOnline = () => setNetworkMode('online');
    const handleOffline = () => setNetworkMode('offline');
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const t = translations[language];

  const pendingSyncCount = ashaRecords.filter((r) => !r.synced).length;

  const addGrievance = (g: Omit<GrievanceReport, 'id' | 'trackingId' | 'status' | 'createdAt'>): string => {
    const randomNum = Math.floor(1000 + Math.random() * 9000);
    const trackingId = `MH-PHC-2026-${randomNum}`;
    const newGrievance: GrievanceReport = {
      ...g,
      id: `grv-${Date.now()}`,
      trackingId,
      status: 'Under Investigation',
      createdAt: new Date().toISOString(),
    };
    setGrievances((prev) => [newGrievance, ...prev]);
    return trackingId;
  };

  const getGrievanceByTrackingId = (trackingId: string): GrievanceReport | undefined => {
    const cleanId = trackingId.trim().toUpperCase();
    return grievances.find((g) => g.trackingId.toUpperCase() === cleanId);
  };

  const addAshaRecord = (rec: Omit<AshaPatientRecord, 'id' | 'synced' | 'timestamp'>) => {
    const isOffline = networkMode === 'offline';
    const newRecord: AshaPatientRecord = {
      ...rec,
      id: `ash-${Date.now()}`,
      synced: !isOffline,
      timestamp: Date.now(),
    };
    setAshaRecords((prev) => [newRecord, ...prev]);
  };

  const syncPendingRecords = async (): Promise<number> => {
    // Simulating low-bandwidth sync
    return new Promise((resolve) => {
      setTimeout(() => {
        let count = 0;
        setAshaRecords((prev) =>
          prev.map((item) => {
            if (!item.synced) {
              count++;
              return { ...item, synced: true };
            }
            return item;
          })
        );
        resolve(count);
      }, 1000);
    });
  };

  const bookConsultation = (booking: Omit<TeleconsultationBooking, 'id' | 'status' | 'createdAt'>): TeleconsultationBooking => {
    const newBooking: TeleconsultationBooking = {
      ...booking,
      id: `tele-${Date.now()}`,
      status: 'Waiting',
      createdAt: new Date().toISOString(),
    };
    setConsultations((prev) => [newBooking, ...prev]);
    setActiveConsultation(newBooking);
    return newBooking;
  };

  return (
    <AppContext.Provider
      value={{
        language,
        setLanguage,
        t,
        networkMode,
        setNetworkMode,
        dataSaver,
        setDataSaver,
        textSize,
        setTextSize,
        activeTab,
        setActiveTab,
        facilities,
        selectedFacility,
        setSelectedFacility,
        medicines,
        medicineSearch,
        setMedicineSearch,
        grievances,
        addGrievance,
        getGrievanceByTrackingId,
        ashaRecords,
        addAshaRecord,
        syncPendingRecords,
        pendingSyncCount,
        consultations,
        activeConsultation,
        setActiveConsultation,
        bookConsultation,
        alertMessage,
        setAlertMessage,
      }}
    >
      <div className={textSize === 'large' ? 'text-lg' : textSize === 'xlarge' ? 'text-xl' : 'text-base'}>
        {children}
      </div>
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
