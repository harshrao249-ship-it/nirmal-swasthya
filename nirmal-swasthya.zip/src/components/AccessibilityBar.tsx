import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Volume2, VolumeX, PhoneCall, HelpCircle, Eye, Check } from 'lucide-react';
import { speakText, stopSpeech } from '../utils/speech';

export const AccessibilityBar: React.FC = () => {
  const { language, t, textSize, setTextSize } = useApp();
  const [isSpeaking, setIsSpeaking] = useState(false);

  const handleReadHelp = () => {
    if (isSpeaking) {
      stopSpeech();
      setIsSpeaking(false);
    } else {
      const speechPrompt =
        language === 'mr'
          ? 'निर्मल स्वास्थ्य पोर्टलमध्ये आपले स्वागत आहे. येथे आपण जवळचे प्राथमिक आरोग्य केंद्र शोधू शकता, मोफत सरकारी डॉक्टरांशी व्हिडिओ किंवा ऑडिओ कॉलवर बोलू शकता, आणि सरकारी औषधांचा साठा तपासू शकता. आपत्कालीन मदतीसाठी १०८ वर संपर्क करा.'
          : language === 'hi'
          ? 'निर्मल स्वास्थ्य पोर्टल में आपका स्वागत है। यहां आप नजदीकी प्राथमिक स्वास्थ्य केंद्र ढूंढ सकते हैं, विशेषज्ञ डॉक्टर से टेली-परामर्श ले सकते हैं और मुफ्त दवाओं का स्टॉक देख सकते हैं। आपातकालीन सहायता के लिए १०८ डायल करें।'
          : 'Welcome to Nirmal Swasthya portal. Find your nearest primary health center, book free tele-consultations with government doctors, and check live essential medicine stocks. For emergency, dial 108.';

      setIsSpeaking(true);
      speakText(speechPrompt, language);
      setTimeout(() => setIsSpeaking(false), 9000);
    }
  };

  return (
    <div className="bg-amber-50 border-b border-amber-200 px-3 py-2 text-xs sm:text-sm text-slate-800">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
        {/* Voice Read Aloud Assistance for seniors / low-literacy */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleReadHelp}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-full font-semibold border transition-all shadow-xs active:scale-95 ${
              isSpeaking
                ? 'bg-amber-500 text-white border-amber-600 animate-pulse'
                : 'bg-white text-amber-900 border-amber-300 hover:bg-amber-100'
            }`}
            title="Listen to instructions (मोठ्याने ऐका / बोलकर सुनें)"
          >
            {isSpeaking ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-amber-600" />}
            <span>
              {language === 'mr'
                ? 'मोठ्याने ऐका (बोलून दाखवा)'
                : language === 'hi'
                ? 'बोलकर सुनें (आवाज सहायता)'
                : 'Listen to Page (Audio Assist)'}
            </span>
          </button>
          <span className="hidden sm:inline text-amber-900/70 text-xs">
            {language === 'mr'
              ? 'सर्व वयोगटांसाठी व ज्येष्ठ नागरिकांसाठी सुलभ'
              : language === 'hi'
              ? 'वरिष्ठ नागरिकों व सभी के लिए आसान'
              : 'Designed for easy use by all age groups'}
          </span>
        </div>

        {/* Quick Help & Large font indicator */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 bg-white px-2.5 py-1 rounded-full border border-amber-200 text-xs font-medium text-slate-700">
            <Eye className="w-3.5 h-3.5 text-blue-700" />
            <span>{t.textSize}:</span>
            <button
              onClick={() => setTextSize('normal')}
              className={`px-1.5 py-0.5 rounded ${textSize === 'normal' ? 'bg-blue-600 text-white font-bold' : 'hover:bg-slate-100'}`}
            >
              साधा
            </button>
            <button
              onClick={() => setTextSize('large')}
              className={`px-1.5 py-0.5 rounded ${textSize === 'large' ? 'bg-blue-600 text-white font-bold' : 'hover:bg-slate-100'}`}
            >
              मोठा
            </button>
            <button
              onClick={() => setTextSize('xlarge')}
              className={`px-1.5 py-0.5 rounded ${textSize === 'xlarge' ? 'bg-blue-600 text-white font-bold' : 'hover:bg-slate-100'}`}
            >
              अति-मोठा
            </button>
          </div>

          <a
            href="tel:108"
            className="flex items-center gap-1.5 bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded-full font-bold shadow-xs transition-colors"
          >
            <PhoneCall className="w-3.5 h-3.5" />
            <span>SOS 108</span>
          </a>
        </div>
      </div>
    </div>
  );
};
