import React from 'react';
import { useApp } from '../context/AppContext';
import {
  Baby,
  Syringe,
  FlaskConical,
  Video,
  ShieldAlert,
  HeartHandshake,
  Activity,
  ArrowUpRight,
  Pill,
} from 'lucide-react';

export const CoreServicesGrid: React.FC = () => {
  const { language, setActiveTab } = useApp();

  const services = [
    {
      id: 'maternal',
      icon: Baby,
      color: 'bg-rose-50 text-rose-700 border-rose-200',
      tagMr: 'माता व बाल संगोपन',
      tagEn: 'Maternal & Child Care',
      titleMr: 'गर्भवती माता तपासणी व मोफत प्रसूती',
      titleEn: 'ANC Checkups & 24x7 Institutional Delivery',
      descMr:
        'गरोदर महिलांसाठी नियमित सोनोग्राफी, रक्ततपासणी, लोहयुक्त गोळ्या आणि जननी सुरक्षा योजनेंतर्गत मोफत रुग्णवाहिका व लाभ.',
      descEn:
        'Comprehensive antenatal care, free transport under Janani Shishu Suraksha, institutional delivery, and nutritional kits.',
      actionTab: 'locator' as const,
      badge: '२४x७ मोफत',
    },
    {
      id: 'immunization',
      icon: Syringe,
      color: 'bg-blue-50 text-blue-700 border-blue-200',
      tagMr: 'बाल लसीकरण मोहीम',
      tagEn: 'Universal Immunization',
      titleMr: 'मिशन इंद्रधनुष्य: सर्व बालकांचे मोफत लसीकरण',
      titleEn: 'Complete Child Immunization Schedule',
      descMr:
        'बीसीजी, पोलिओ, पेंटाव्हॅलेंट, गोवर-रुबेला (MR) व जपानी एन्सेफलायटिस अशा सर्व १२ गंभीर आजारांवर संपूर्ण मोफत लस.',
      descEn:
        'Lifesaving vaccines for newborns and infants up to 5 years via village Anganwadis and PHC outreach sessions.',
      actionTab: 'locator' as const,
      badge: '१००% मोफत',
    },
    {
      id: 'telemed',
      icon: Video,
      color: 'bg-emerald-50 text-emerald-700 border-emerald-200',
      tagMr: 'ई-संजीवनी डिजिटल ओपीडी',
      tagEn: 'e-Sanjeevani Telemedicine',
      titleMr: 'गावात बसून जिल्हा तज्ज्ञ डॉक्टरांचा सल्ला',
      titleEn: 'Direct Video Consult with MD Specialists',
      descMr:
        'कमी 2G/3G इंटरनेटवर ऑडिओ किंवा व्हिडिओ कॉलद्वारे तज्ज्ञ वैद्यकीय सल्ला. त्वरित डिजिटल प्रिस्क्रिप्शन मोबाईलवर प्राप्त.',
      descEn:
        'Low-bandwidth video consultations connecting rural patients to district hospital specialists and medical colleges.',
      actionTab: 'telemed' as const,
      badge: 'थेट कॉल',
    },
    {
      id: 'diagnostics',
      icon: FlaskConical,
      color: 'bg-purple-50 text-purple-700 border-purple-200',
      tagMr: 'मोफत निदान चाचण्या',
      tagEn: 'Free Diagnostic Lab Tests',
      titleMr: '६०+ पॅथॉलॉजी व रक्त तपासण्या विनामूल्य',
      titleEn: 'Free Diagnostics Initiative (60+ Tests)',
      descMr:
        'रक्तातील साखर (Diabetes), हिमोग्लोबिन (Hb), मलेरिया, डेंग्यू, थायरॉईड, ईसीजी आणि लघवी तपासणी अहवाल त्याच दिवशी उपलब्ध.',
      descEn:
        'Free blood counts, rapid malaria/dengue screening, lipid profile, HbA1c, and ECG at all Primary Health Centers.',
      actionTab: 'locator' as const,
      badge: 'त्याच दिवशी रिपोर्ट',
    },
    {
      id: 'snakebite',
      icon: ShieldAlert,
      color: 'bg-amber-50 text-amber-700 border-amber-200',
      tagMr: 'तातडीचे विषबाधा नियंत्रण',
      tagEn: 'Emergency Envenomation Protocol',
      titleMr: 'सर्पदंश व विंचूदंश तातडीचे उपचार (ASV)',
      titleEn: 'Snakebite Emergency & Anti-Venom Bank',
      descMr:
        'शेतकरी व ग्रामीण नागरिकांसाठी २४ तास अँटी-स्नेक व्हेनम लस उपलब्ध. गोल्डन अवरमध्ये तात्काळ जीव वाचवणारी वैद्यकीय मदत.',
      descEn:
        'Round-the-clock Anti-Snake Venom (ASVS) serum buffer stock at every rural PHC with trained resuscitation teams.',
      actionTab: 'medicines' as const,
      badge: 'आपत्कालीन सज्ज',
    },
    {
      id: 'chronic',
      icon: HeartHandshake,
      color: 'bg-teal-50 text-teal-700 border-teal-200',
      tagMr: 'ज्येष्ठ नागरिक व असंसर्गजन्य आजार',
      tagEn: 'Elderly Wellness & NCD Care',
      titleMr: 'बीपी व डायबिटीस औषधांचा घरपोच / केंद्र पुरवठा',
      titleEn: 'Chronic Care & Senior Citizen Clinic',
      descMr:
        '३० वर्षांवरील सर्व नागरिकांची मोफत बीपी व शुगर तपासणी, दरमहा ३० दिवसांचा औषध पुरवठा आणि नियमित पाठपुरावा.',
      descEn:
        'Monthly medication dispensation for hypertension and diabetes, geriatric health camps, and doorstep ASHA visits.',
      actionTab: 'medicines' as const,
      badge: 'दरमहा औषध',
    },
  ];

  return (
    <section className="py-12 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-100 text-emerald-900 text-xs font-semibold mb-2">
            <Activity className="w-3.5 h-3.5 text-emerald-700" />
            <span>
              {language === 'mr'
                ? 'सार्वजनिक आरोग्य विभागाच्या प्रमुख सेवा'
                : 'National Health Mission Maharashtra Services'}
            </span>
          </div>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-[#0b2545] tracking-tight">
            {language === 'mr'
              ? 'ग्रामीण नागरिकांसाठी मोफत शासकीय आरोग्य सेवा'
              : 'Core Public Health Services for Rural Citizens'}
          </h2>
          <p className="text-slate-600 mt-2 text-sm sm:text-base">
            {language === 'mr'
              ? 'महाराष्ट्र शासनाच्या सर्व प्राथमिक आरोग्य केंद्रांमध्ये औषधे, तपासण्या व सल्लामसलत पूर्णपणे मोफत उपलब्ध आहेत.'
              : 'Zero out-of-pocket expenditure: Diagnostics, delivery, essential medicines, and specialist consultations are 100% free.'}
          </p>
        </div>

        {/* Services 3x2 Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((srv) => {
            const IconComponent = srv.icon;
            return (
              <div
                key={srv.id}
                className="rounded-2xl border border-slate-200 p-6 flex flex-col justify-between hover:border-blue-300 hover:shadow-md transition-all bg-white group"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center border ${srv.color} group-hover:scale-105 transition-transform`}>
                      <IconComponent className="w-6 h-6" />
                    </div>
                    <span className="text-[11px] font-bold px-2.5 py-1 rounded-full bg-slate-100 text-slate-800 border border-slate-200">
                      {srv.badge}
                    </span>
                  </div>

                  <span className="text-xs font-bold text-blue-700 uppercase tracking-wider block">
                    {language === 'mr' ? srv.tagMr : srv.tagEn}
                  </span>

                  <h3 className="text-lg font-bold text-slate-900 mt-1 leading-snug group-hover:text-blue-900 transition-colors">
                    {language === 'mr' ? srv.titleMr : srv.titleEn}
                  </h3>

                  <p className="text-slate-600 text-xs sm:text-sm mt-2 leading-relaxed">
                    {language === 'mr' ? srv.descMr : srv.descEn}
                  </p>
                </div>

                <div className="pt-5 mt-4 border-t border-slate-100">
                  <button
                    onClick={() => setActiveTab(srv.actionTab)}
                    className="w-full flex items-center justify-between text-xs sm:text-sm font-bold text-blue-800 hover:text-blue-950 py-1 group/btn"
                  >
                    <span>
                      {srv.actionTab === 'telemed'
                        ? language === 'mr' ? 'टेलि-सल्ला सुरू करा' : 'Start Tele-Consult'
                        : srv.actionTab === 'medicines'
                        ? language === 'mr' ? 'औषध साठा शोधा' : 'Check Stock'
                        : language === 'mr' ? 'केंद्र व ओपीडी तपासा' : 'Find Nearby Facility'}
                    </span>
                    <ArrowUpRight className="w-4 h-4 group-hover/btn:translate-x-0.5 group-hover/btn:-translate-y-0.5 transition-transform" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
