import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  HeartPulse,
  Star,
  CheckCircle2,
  AlertTriangle,
  Search,
  MessageSquare,
  Building2,
  Phone,
  Clock,
  ShieldCheck,
  Send,
} from 'lucide-react';
import { GrievanceReport } from '../types';

export const GrievanceForm: React.FC = () => {
  const { facilities, addGrievance, getGrievanceByTrackingId, language, t } = useApp();

  // Rating States (1-5)
  const [cleanlinessRating, setCleanlinessRating] = useState<number>(4);
  const [doctorRating, setDoctorRating] = useState<number>(4);
  const [medicineRating, setMedicineRating] = useState<number>(3);

  // Facility Selection
  const [facilityId, setFacilityId] = useState<string>(facilities[0]?.id || '');
  const [selectedIssues, setSelectedIssues] = useState<string[]>([]);
  const [comments, setComments] = useState<string>('');
  const [citizenName, setCitizenName] = useState<string>('संतोष जाधव');
  const [citizenPhone, setCitizenPhone] = useState<string>('9823123456');

  // Submission Status
  const [generatedTrackingId, setGeneratedTrackingId] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Tracking Search
  const [searchTrackingId, setSearchTrackingId] = useState<string>('MH-PHC-2026-8492');
  const [trackedRecord, setTrackedRecord] = useState<GrievanceReport | null>(null);
  const [searchPerformed, setSearchPerformed] = useState(false);

  const commonIssues = [
    { id: 'absent', labelMr: t.issueDoctorAbsent },
    { id: 'outsideMeds', labelMr: t.issueOutsideMeds },
    { id: 'dirty', labelMr: t.issueDirtyToilets },
    { id: 'wait', labelMr: t.issueLongWait },
    { id: 'staff', labelMr: t.issueRudeStaff },
    { id: 'ambulance', labelMr: t.issueNoAmbulance },
  ];

  const handleToggleIssue = (issueLabel: string) => {
    setSelectedIssues((prev) =>
      prev.includes(issueLabel) ? prev.filter((i) => i !== issueLabel) : [...prev, issueLabel]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    const chosenFacility = facilities.find((f) => f.id === facilityId) || facilities[0];
    const overall = Number(((cleanlinessRating + doctorRating + medicineRating) / 3).toFixed(1));

    setTimeout(() => {
      const trackingId = addGrievance({
        facilityId: chosenFacility.id,
        facilityName: chosenFacility.name,
        district: chosenFacility.district,
        cleanlinessRating,
        doctorAvailabilityRating: doctorRating,
        medicineSupplyRating: medicineRating,
        overallRating: overall,
        issues: selectedIssues,
        comments,
        citizenName,
        citizenPhone,
      });

      setGeneratedTrackingId(trackingId);
      setIsSubmitting(false);
    }, 600);
  };

  const handleSearchTracking = (e: React.FormEvent) => {
    e.preventDefault();
    setSearchPerformed(true);
    const result = getGrievanceByTrackingId(searchTrackingId);
    setTrackedRecord(result || null);
  };

  return (
    <section className="py-10 bg-white border-b border-slate-200" id="grievance">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="mb-8 text-center sm:text-left">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-100 text-purple-900 text-xs font-semibold mb-2">
            <HeartPulse className="w-3.5 h-3.5 text-purple-700" />
            <span>{language === 'mr' ? 'नागरिक अधिकार व पारदर्शकता' : 'Citizen Charter & Quality Monitoring'}</span>
          </div>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-[#0b2545] tracking-tight">
            {t.grievanceTitle}
          </h2>
          <p className="text-slate-600 mt-2 text-sm sm:text-base max-w-3xl">
            {t.grievanceSubtitle}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left: Feedback & Grievance Submission Form */}
          <div className="lg:col-span-7">
            <div className="bg-slate-50 rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-xs">
              {!generatedTrackingId ? (
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Select Facility */}
                  <div>
                    <label className="block text-xs font-bold text-slate-800 mb-1.5">
                      {language === 'mr' ? 'आरोग्य केंद्र निवडा (Select Facility) *' : 'Select Health Facility *'}
                    </label>
                    <select
                      value={facilityId}
                      onChange={(e) => setFacilityId(e.target.value)}
                      className="w-full px-3.5 py-3 rounded-lg border border-slate-300 bg-white font-medium text-slate-900 focus:ring-2 focus:ring-blue-600 text-sm"
                    >
                      {facilities.map((fac) => (
                        <option key={fac.id} value={fac.id}>
                          {language === 'mr' ? fac.nameMr : fac.name} ({fac.district})
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* 3 Large Rating Blocks with Interactive Stars */}
                  <div className="space-y-4 bg-white p-4 rounded-xl border border-slate-200">
                    <div className="font-bold text-xs text-slate-700 uppercase tracking-wider">
                      {language === 'mr' ? 'आरोग्य केंद्र दर्जा मूल्यांकन (१ ते ५ स्टार):' : 'Quality Assessment Ratings (1 to 5 Stars):'}
                    </div>

                    {/* Cleanliness Rating */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
                      <div>
                        <span className="font-bold text-slate-900 text-sm block">{t.rateCleanliness}</span>
                        <span className="text-[11px] text-slate-500">वॉर्ड, बेडशीट आणि स्वच्छतागृहांची स्वच्छता</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <button
                            key={star}
                            type="button"
                            onClick={() => setCleanlinessRating(star)}
                            className="p-1 text-2xl transition-transform hover:scale-125 focus:outline-none"
                          >
                            <Star
                              className={`w-7 h-7 ${
                                star <= cleanlinessRating
                                  ? 'text-amber-400 fill-amber-400'
                                  : 'text-slate-200'
                              }`}
                            />
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Staff & Doctor Availability */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
                      <div>
                        <span className="font-bold text-slate-900 text-sm block">{t.rateStaff}</span>
                        <span className="text-[11px] text-slate-500">डॉक्टर, परिचारिका व औषध वितरकांचे वर्तन</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <button
                            key={star}
                            type="button"
                            onClick={() => setDoctorRating(star)}
                            className="p-1 text-2xl transition-transform hover:scale-125 focus:outline-none"
                          >
                            <Star
                              className={`w-7 h-7 ${
                                star <= doctorRating
                                  ? 'text-amber-400 fill-amber-400'
                                  : 'text-slate-200'
                              }`}
                            />
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Medicine Supply */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div>
                        <span className="font-bold text-slate-900 text-sm block">{t.rateMeds}</span>
                        <span className="text-[11px] text-slate-500">डॉक्टरांनी लिहून दिलेली सर्व औषधे मोफत मिळाली का?</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <button
                            key={star}
                            type="button"
                            onClick={() => setMedicineRating(star)}
                            className="p-1 text-2xl transition-transform hover:scale-125 focus:outline-none"
                          >
                            <Star
                              className={`w-7 h-7 ${
                                star <= medicineRating
                                  ? 'text-amber-400 fill-amber-400'
                                  : 'text-slate-200'
                              }`}
                            />
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Checkbox of Common Issues */}
                  <div>
                    <label className="block text-xs font-bold text-slate-800 mb-2">
                      {t.checkIssues}
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {commonIssues.map((issue) => {
                        const isChecked = selectedIssues.includes(issue.labelMr);
                        return (
                          <button
                            key={issue.id}
                            type="button"
                            onClick={() => handleToggleIssue(issue.labelMr)}
                            className={`p-2.5 rounded-lg border text-left text-xs font-medium flex items-center gap-2 transition-all ${
                              isChecked
                                ? 'bg-red-50 border-red-300 text-red-900 font-bold'
                                : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                            }`}
                          >
                            <div
                              className={`w-4 h-4 rounded border flex items-center justify-center shrink-0 text-[10px] ${
                                isChecked ? 'bg-red-600 border-red-600 text-white font-bold' : 'border-slate-300'
                              }`}
                            >
                              {isChecked && '✓'}
                            </div>
                            <span className="leading-snug">{issue.labelMr}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Free Text Description */}
                  <div>
                    <label className="block text-xs font-bold text-slate-800 mb-1">
                      {t.enterDetails}
                    </label>
                    <textarea
                      rows={3}
                      value={comments}
                      onChange={(e) => setComments(e.target.value)}
                      placeholder={
                        language === 'mr'
                          ? 'आपल्या अनुभवाचे सविस्तर वर्णन लिहा...'
                          : 'Describe any specific problems, dates, or positive feedback...'
                      }
                      className="w-full px-3.5 py-2.5 border border-slate-300 rounded-lg text-sm bg-white focus:ring-2 focus:ring-blue-600"
                    />
                  </div>

                  {/* Citizen Contact Meta */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        आपले नाव (नागरिक नाव) *
                      </label>
                      <input
                        type="text"
                        value={citizenName}
                        onChange={(e) => setCitizenName(e.target.value)}
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm bg-white"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        मोबाईल क्रमांक (अपडेट्ससाठी) *
                      </label>
                      <input
                        type="tel"
                        value={citizenPhone}
                        onChange={(e) => setCitizenPhone(e.target.value)}
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm bg-white"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-4 bg-[#0f3b6c] hover:bg-[#0b2545] text-white font-bold rounded-xl text-base shadow-md transition-all flex items-center justify-center gap-2 min-h-[52px]"
                  >
                    <Send className="w-5 h-5 text-emerald-300" />
                    <span>{isSubmitting ? 'तक्रार नोंदवत आहे...' : t.submitGrievance}</span>
                  </button>
                </form>
              ) : (
                /* Success Acknowledgement with Tracking ID */
                <div className="text-center py-6 space-y-4">
                  <div className="w-16 h-16 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto">
                    <CheckCircle2 className="w-10 h-10" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-emerald-700 uppercase tracking-wider">
                      अभिप्राय / तक्रार यशस्वीरित्या नोंदवली गेली!
                    </span>
                    <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
                      {generatedTrackingId}
                    </h3>
                    <p className="text-xs text-slate-500 mt-1">
                      आपला ट्रॅकिंग क्रमांक जपून ठेवा. जिल्हा आरोग्य अधिकाऱ्यांमार्फत ४८ तासांत चौकशी होईल.
                    </p>
                  </div>

                  <div className="bg-white p-4 rounded-xl border border-slate-200 text-left text-xs space-y-1.5 max-w-md mx-auto text-slate-700">
                    <div><strong>स्थिती:</strong> <span className="text-amber-700 font-bold">Under Investigation</span></div>
                    <div><strong>अभिप्राय वर्गवारी:</strong> गुणवत्ता निर्देशांक व तक्रार निवारण</div>
                    <div><strong>सूचना:</strong> कारवाईचा एसएमएस आपल्या नोंदणीकृत क्रमांकावर पाठवला जाईल.</div>
                  </div>

                  <button
                    onClick={() => {
                      setGeneratedTrackingId(null);
                      setSelectedIssues([]);
                      setComments('');
                    }}
                    className="px-6 py-2.5 bg-blue-700 text-white rounded-lg text-xs font-bold"
                  >
                    दुसरा अभिप्राय नोंदवा (Submit Another)
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Right: Grievance Redressal Status Tracker & Public Transparency */}
          <div className="lg:col-span-5 space-y-6">
            {/* Tracking Card */}
            <div className="bg-slate-50 rounded-2xl border border-slate-200 p-6 shadow-xs">
              <div className="flex items-center gap-2 mb-3">
                <Search className="w-5 h-5 text-blue-700" />
                <h3 className="font-bold text-slate-900 text-base">
                  {t.trackTitle}
                </h3>
              </div>
              <p className="text-xs text-slate-500 mb-4">
                तक्रारीवर झालेली कारवाई व जिल्हा आरोग्य अधिकाऱ्यांचा (DHO) अहवाल पहा.
              </p>

              <form onSubmit={handleSearchTracking} className="flex gap-2 mb-4">
                <input
                  type="text"
                  value={searchTrackingId}
                  onChange={(e) => setSearchTrackingId(e.target.value)}
                  placeholder={t.trackPlaceholder}
                  className="flex-1 px-3 py-2.5 border border-slate-300 rounded-lg text-xs sm:text-sm font-medium focus:ring-2 focus:ring-blue-600 bg-white"
                />
                <button
                  type="submit"
                  className="px-4 py-2.5 bg-blue-700 hover:bg-blue-800 text-white font-bold rounded-lg text-xs whitespace-nowrap transition-colors"
                >
                  {t.trackBtn}
                </button>
              </form>

              {/* Display tracked result if searched */}
              {searchPerformed && (
                trackedRecord ? (
                  <div className="bg-white p-4 rounded-xl border border-slate-200 text-xs space-y-3">
                    <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                      <span className="font-bold text-slate-900">{trackedRecord.trackingId}</span>
                      <span
                        className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                          trackedRecord.status === 'Resolved' || trackedRecord.status === 'Closed'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {trackedRecord.status}
                      </span>
                    </div>

                    <div>
                      <span className="text-slate-500 block">आरोग्य केंद्र:</span>
                      <span className="font-bold text-slate-900">{trackedRecord.facilityName} ({trackedRecord.district})</span>
                    </div>

                    <div>
                      <span className="text-slate-500 block">तक्रार तपशील:</span>
                      <p className="text-slate-700 italic">"{trackedRecord.comments || 'Cleanliness & Medicine feedback'}"</p>
                    </div>

                    {trackedRecord.resolutionNote && (
                      <div className="bg-emerald-50 p-2.5 rounded-lg border border-emerald-200 text-emerald-900">
                        <span className="font-bold block mb-0.5">प्रशासकीय कारवाई अहवाल:</span>
                        <span>{trackedRecord.resolutionNote}</span>
                      </div>
                    )}

                    <span className="text-[10px] text-slate-400 block pt-1">
                      नोंदणी दिनांक: {new Date(trackedRecord.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                ) : (
                  <div className="bg-amber-50 p-3 rounded-lg border border-amber-200 text-amber-900 text-xs">
                    तपशील सापडला नाही. कृपया वैध ट्रॅकिंग क्रमांक प्रविष्ट करा (उदा. MH-PHC-2026-8492 किंवा MH-PHC-2026-7215).
                  </div>
                )
              )}
            </div>

            {/* Public Health Transparency Guarantee Card */}
            <div className="bg-gradient-to-br from-blue-900 to-[#0b2545] rounded-2xl p-6 text-white space-y-4">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-6 h-6 text-emerald-400 shrink-0" />
                <h4 className="font-bold text-base">महाराष्ट्र शासन पारदर्शकता हमी</h4>
              </div>
              <p className="text-xs text-blue-100 leading-relaxed">
                सर्व तक्रारी थेट जिल्हाधिकारी आणि जिल्हा आरोग्य अधिकारी (DHO) यांच्या डॅशबोर्डवर दिसतात. प्रत्येक प्राथमिक आरोग्य केंद्राचे मासिक स्वच्छतेचे व डॉक्टर उपस्थितीचे गुण सार्वजनिकरित्या प्रदर्शित केले जातात.
              </p>
              <div className="grid grid-cols-2 gap-2 pt-2 border-t border-blue-800 text-xs">
                <div>
                  <span className="text-blue-300 block text-[11px]">सरासरी निवारण वेळ</span>
                  <span className="font-extrabold text-white text-base">४८ तास</span>
                </div>
                <div>
                  <span className="text-blue-300 block text-[11px]">तक्रार निवारण दर</span>
                  <span className="font-extrabold text-emerald-400 text-base">९४.८%</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
