import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Language, TeleconsultationBooking } from '../types';
import teleDoctorImg from '../assets/images/telemedicine_doctor_1790169671660.jpg';
import {
  Video,
  Mic,
  MicOff,
  VideoOff,
  PhoneOff,
  Volume2,
  Camera,
  Upload,
  User,
  Baby,
  Heart,
  Users,
  AlertCircle,
  CheckCircle,
  FileText,
  Printer,
  ShieldCheck,
  Zap,
  Globe,
  Stethoscope,
  Activity,
  Calendar,
} from 'lucide-react';
import { speakText } from '../utils/speech';

export const TelemedicinePortal: React.FC = () => {
  const { language, t, networkMode, dataSaver, bookConsultation, activeConsultation, setActiveConsultation } = useApp();

  // Step state
  const [currentStep, setCurrentStep] = useState<1 | 2 | 3 | 4>(1);

  // Form states
  const [patientName, setPatientName] = useState('कमलाबाई शंकर पवार');
  const [patientAge, setPatientAge] = useState('54');
  const [patientGender, setPatientGender] = useState<'Female' | 'Male' | 'Other'>('Female');
  const [patientCategory, setPatientCategory] = useState<'General' | 'Pregnant Mother (ANC)' | 'Child Under 5' | 'Elderly / Chronic'>('Elderly / Chronic');
  const [village, setVillage] = useState('घोडेगाव (Ambegaon taluka)');
  const [phone, setPhone] = useState('9823456789');
  const [selectedLanguage, setSelectedLanguage] = useState<Language>(language);

  // Symptoms
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>(['ताप व थंडी (Fever)', 'खोकला व श्वास लागणे (Cough/Breathlessness)']);
  const [severity, setSeverity] = useState<'Mild' | 'Moderate' | 'Severe / Emergency'>('Moderate');
  const [clinicalNotes, setClinicalNotes] = useState('गेल्या ३ दिवसांपासून ताप आणि अंगदुखी आहे. स्थानिक औषध घेऊनही फरक पडला नाही.');

  // Vitals
  const [bp, setBp] = useState('130/84');
  const [pulse, setPulse] = useState('82');
  const [spo2, setSpo2] = useState('98');
  const [temperature, setTemperature] = useState('100.4');

  // Photo simulation
  const [hasUploadedPhoto, setHasUploadedPhoto] = useState(false);

  // Call simulation state
  const [callConnected, setCallConnected] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [lowBandwidthVoiceOnly, setLowBandwidthVoiceOnly] = useState(networkMode === 'slow-3g' || dataSaver);
  const [callDuration, setCallDuration] = useState(128); // seconds
  const [prescriptionIssued, setPrescriptionIssued] = useState(false);

  const symptomList = [
    { id: 'fever', labelMr: 'ताप व थंडी (Fever & Chills)', icon: '🌡️' },
    { id: 'cough', labelMr: 'खोकला व श्वास लागणे (Cough/Breathing)', icon: '🫁' },
    { id: 'abdomen', labelMr: 'पोटदुखी व जुलाब (Stomach Pain/Diarrhea)', icon: '🤢' },
    { id: 'pregnancy', labelMr: 'गरोदरपणातील तपासणी (ANC Checkup)', icon: '🤰' },
    { id: 'skin', labelMr: 'त्वचेवर खाज किंवा पुरळ (Skin Rash)', icon: '🩹' },
    { id: 'joint', labelMr: 'गुडघेदुखी व सांधेदुखी (Joint Pain / Senior)', icon: '🦴' },
    { id: 'pediatric', labelMr: 'बालकाचा ताप/उलट्या (Child Sick)', icon: '👶' },
    { id: 'snakebite', labelMr: 'विंचू / किटक चावणे (Bite/Sting - Urgent)', icon: '⚠️' },
  ];

  const handleToggleSymptom = (labelMr: string) => {
    setSelectedSymptoms((prev) =>
      prev.includes(labelMr) ? prev.filter((s) => s !== labelMr) : [...prev, labelMr]
    );
  };

  const handleStartConsultation = () => {
    const booking = bookConsultation({
      patientName,
      age: Number(patientAge) || 45,
      gender: patientGender,
      category: patientCategory,
      phone,
      village,
      district: 'Pune Rural',
      preferredLanguage: selectedLanguage,
      symptoms: selectedSymptoms,
      severity,
      vitals: {
        bp,
        pulse: Number(pulse) || 80,
        spo2: Number(spo2) || 98,
        temperature: Number(temperature) || 98.6,
      },
      clinicalNotes,
      prescriptionSlipAttached: hasUploadedPhoto,
    });

    setCurrentStep(4);
    setTimeout(() => {
      setCallConnected(true);
    }, 1500);
  };

  const handlePrintPrescription = () => {
    window.print();
  };

  return (
    <section className="py-10 bg-slate-50 border-b border-slate-200" id="telemedicine">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="mb-6 text-center sm:text-left">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-100 text-emerald-900 text-xs font-semibold mb-2">
            <Video className="w-3.5 h-3.5 text-emerald-700" />
            <span>e-Sanjeevani 2.0 Rural Maharashtra</span>
          </div>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-[#0b2545] tracking-tight">
            {t.telemedTitle}
          </h2>
          <p className="text-slate-600 mt-2 text-sm sm:text-base max-w-3xl">
            {t.telemedSubtitle}
          </p>
        </div>

        {/* 4-Step Progress Bar (High clarity for rural citizens & ASHA workers) */}
        <div className="bg-white p-3 sm:p-4 rounded-xl border border-slate-200 shadow-xs mb-8">
          <div className="grid grid-cols-4 gap-2 text-center text-xs font-bold">
            <button
              onClick={() => setCurrentStep(1)}
              className={`p-2 rounded-lg border transition-all ${
                currentStep === 1
                  ? 'bg-blue-50 border-blue-600 text-blue-900 shadow-xs'
                  : currentStep > 1
                  ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                  : 'bg-slate-50 border-slate-200 text-slate-400'
              }`}
            >
              <span className="block text-sm sm:text-base">१</span>
              <span className="truncate block mt-0.5">{language === 'mr' ? 'रुग्ण माहिती' : 'Patient'}</span>
            </button>

            <button
              onClick={() => setCurrentStep(2)}
              className={`p-2 rounded-lg border transition-all ${
                currentStep === 2
                  ? 'bg-blue-50 border-blue-600 text-blue-900 shadow-xs'
                  : currentStep > 2
                  ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                  : 'bg-slate-50 border-slate-200 text-slate-400'
              }`}
            >
              <span className="block text-sm sm:text-base">२</span>
              <span className="truncate block mt-0.5">{language === 'mr' ? 'लक्षणे व भाषा' : 'Symptoms'}</span>
            </button>

            <button
              onClick={() => setCurrentStep(3)}
              className={`p-2 rounded-lg border transition-all ${
                currentStep === 3
                  ? 'bg-blue-50 border-blue-600 text-blue-900 shadow-xs'
                  : currentStep > 3
                  ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                  : 'bg-slate-50 border-slate-200 text-slate-400'
              }`}
            >
              <span className="block text-sm sm:text-base">३</span>
              <span className="truncate block mt-0.5">{language === 'mr' ? 'तपासणी पॅरामीटर्स' : 'Vitals/Photo'}</span>
            </button>

            <button
              onClick={() => setCurrentStep(4)}
              className={`p-2 rounded-lg border transition-all ${
                currentStep === 4
                  ? 'bg-emerald-600 border-emerald-700 text-white shadow-xs'
                  : 'bg-slate-50 border-slate-200 text-slate-400'
              }`}
            >
              <span className="block text-sm sm:text-base">४</span>
              <span className="truncate block mt-0.5">{language === 'mr' ? 'थेट डॉक्टर कॉल' : 'Doctor Call'}</span>
            </button>
          </div>
        </div>

        {/* Step 1: Patient Details */}
        {currentStep === 1 && (
          <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-sm space-y-6 max-w-3xl mx-auto">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-xl font-bold text-slate-900">{t.step1}</h3>
                <p className="text-xs text-slate-500">
                  {language === 'mr' ? 'रुग्णाची प्राथमिक माहिती भरा' : 'Enter patient demographic details'}
                </p>
              </div>
              <button
                onClick={() =>
                  speakText(
                    language === 'mr'
                      ? 'कृपया रुग्णाचे पूर्ण नाव, वय, लिंग आणि वर्ग निवडा.'
                      : 'Please enter the patient full name, age, and category.'
                  )
                }
                className="p-2 text-slate-500 hover:text-blue-700 bg-slate-100 rounded-full"
                title="Speak instructions"
              >
                <Volume2 className="w-5 h-5" />
              </button>
            </div>

            {/* Patient Category with Large Visual Cards for all age groups */}
            <div>
              <label className="block text-sm font-bold text-slate-800 mb-2">
                {t.category} *
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {[
                  { id: 'Elderly / Chronic', labelMr: 'ज्येष्ठ नागरिक', icon: Users, subMr: '६०+ वर्षे' },
                  { id: 'Pregnant Mother (ANC)', labelMr: 'गर्भवती माता', icon: Heart, subMr: 'ANC तपासणी' },
                  { id: 'Child Under 5', labelMr: 'लहान बाळ / मुल', icon: Baby, subMr: '५ वर्षांखालील' },
                  { id: 'General', labelMr: 'सामान्य नागरिक', icon: User, subMr: 'इतर सर्व वयोगट' },
                ].map((cat) => {
                  const Icon = cat.icon;
                  const isSelected = patientCategory === cat.id;
                  return (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => setPatientCategory(cat.id as any)}
                      className={`p-3 rounded-xl border-2 text-center transition-all flex flex-col items-center justify-center min-h-[90px] ${
                        isSelected
                          ? 'border-blue-600 bg-blue-50/80 text-blue-900 shadow-xs'
                          : 'border-slate-200 hover:border-slate-300 text-slate-700'
                      }`}
                    >
                      <Icon className={`w-6 h-6 mb-1 ${isSelected ? 'text-blue-600' : 'text-slate-400'}`} />
                      <span className="text-xs font-bold block">{cat.labelMr}</span>
                      <span className="text-[10px] text-slate-500 block">{cat.subMr}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {t.patientName} *
                </label>
                <input
                  type="text"
                  value={patientName}
                  onChange={(e) => setPatientName(e.target.value)}
                  className="w-full px-3.5 py-3 border border-slate-300 rounded-lg text-sm font-medium focus:ring-2 focus:ring-blue-600"
                  placeholder="उदा. सखाराम बापू गायकवाड"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {t.patientAge} *
                  </label>
                  <input
                    type="number"
                    value={patientAge}
                    onChange={(e) => setPatientAge(e.target.value)}
                    className="w-full px-3.5 py-3 border border-slate-300 rounded-lg text-sm font-medium focus:ring-2 focus:ring-blue-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {t.gender} *
                  </label>
                  <select
                    value={patientGender}
                    onChange={(e) => setPatientGender(e.target.value as any)}
                    className="w-full px-3 py-3 border border-slate-300 rounded-lg text-sm font-medium bg-white"
                  >
                    <option value="Female">{t.female}</option>
                    <option value="Male">{t.male}</option>
                    <option value="Other">{t.other}</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {t.village} *
                </label>
                <input
                  type="text"
                  value={village}
                  onChange={(e) => setVillage(e.target.value)}
                  className="w-full px-3.5 py-3 border border-slate-300 rounded-lg text-sm font-medium focus:ring-2 focus:ring-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {t.phone} (एसएमएस व प्रिस्क्रिप्शनसाठी) *
                </label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full px-3.5 py-3 border border-slate-300 rounded-lg text-sm font-medium focus:ring-2 focus:ring-blue-600"
                />
              </div>
            </div>

            <div className="pt-4 flex justify-end">
              <button
                type="button"
                onClick={() => setCurrentStep(2)}
                className="w-full sm:w-auto px-8 py-3.5 bg-[#0f3b6c] hover:bg-[#0b2545] text-white font-bold rounded-xl text-base shadow-sm transition-all min-h-[50px]"
              >
                {language === 'mr' ? 'पुढील पायरी: लक्षणे निवडा' : 'Next: Select Symptoms'} &rarr;
              </button>
            </div>
          </div>
        )}

        {/* Step 2: Symptoms & Language Selection */}
        {currentStep === 2 && (
          <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-sm space-y-6 max-w-3xl mx-auto">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-xl font-bold text-slate-900">{t.step2}</h3>
                <p className="text-xs text-slate-500">
                  {language === 'mr' ? 'त्रास आणि डॉक्टरांशी बोलण्याची भाषा निवडा' : 'Select patient symptoms and language preference'}
                </p>
              </div>
              <button
                onClick={() =>
                  speakText(
                    language === 'mr'
                      ? 'आपल्याला जाणवणारी लक्षणे निवडा. एकापेक्षा जास्त लक्षणे निवडू शकता.'
                      : 'Select all symptoms you are currently experiencing.'
                  )
                }
                className="p-2 text-slate-500 hover:text-blue-700 bg-slate-100 rounded-full"
              >
                <Volume2 className="w-5 h-5" />
              </button>
            </div>

            {/* Language Preference for Doctor Call */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 flex items-center gap-1.5">
                <Globe className="w-4 h-4 text-blue-700" />
                <span>{language === 'mr' ? 'डॉक्टरांशी बोलण्याची पसंतीची भाषा (Consultation Language):' : 'Preferred Language:'}</span>
              </label>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { id: 'mr', name: 'मराठी (Marathi)' },
                  { id: 'hi', name: 'हिंदी (Hindi)' },
                  { id: 'en', name: 'English' },
                ].map((l) => (
                  <button
                    key={l.id}
                    type="button"
                    onClick={() => setSelectedLanguage(l.id as Language)}
                    className={`py-2.5 px-3 rounded-xl border text-center font-bold text-sm transition-all ${
                      selectedLanguage === l.id
                        ? 'bg-blue-700 text-white border-blue-800 shadow-xs'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {l.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Symptom Multi-Select with Big Emoji/Icons */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-2">
                {t.symptomsLabel} (लागू असलेली सर्व लक्षणे निवडा):
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {symptomList.map((sym) => {
                  const isChecked = selectedSymptoms.includes(sym.labelMr);
                  return (
                    <button
                      key={sym.id}
                      type="button"
                      onClick={() => handleToggleSymptom(sym.labelMr)}
                      className={`p-3 rounded-xl border text-left flex items-center gap-3 transition-all ${
                        isChecked
                          ? 'border-emerald-600 bg-emerald-50/70 text-emerald-950 font-bold ring-1 ring-emerald-500'
                          : 'border-slate-200 hover:border-slate-300 text-slate-700 bg-slate-50/50'
                      }`}
                    >
                      <span className="text-2xl">{sym.icon}</span>
                      <span className="text-xs sm:text-sm leading-snug flex-1">{sym.labelMr}</span>
                      <div
                        className={`w-5 h-5 rounded-full border flex items-center justify-center text-xs ${
                          isChecked ? 'bg-emerald-600 border-emerald-600 text-white' : 'border-slate-300 bg-white'
                        }`}
                      >
                        {isChecked && '✓'}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Urgency / Severity */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                {t.severity}:
              </label>
              <div className="grid grid-cols-3 gap-2.5">
                {[
                  { id: 'Mild', label: t.severityMild, color: 'hover:border-emerald-400' },
                  { id: 'Moderate', label: t.severityMod, color: 'hover:border-amber-400' },
                  { id: 'Severe / Emergency', label: t.severityHigh, color: 'hover:border-red-400' },
                ].map((s) => (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => setSeverity(s.id as any)}
                    className={`py-2 px-3 rounded-xl border text-xs sm:text-sm font-bold text-center transition-all ${
                      severity === s.id
                        ? s.id === 'Severe / Emergency'
                          ? 'bg-red-600 text-white border-red-700'
                          : s.id === 'Moderate'
                          ? 'bg-amber-600 text-white border-amber-700'
                          : 'bg-emerald-600 text-white border-emerald-700'
                        : 'bg-white text-slate-700 border-slate-200'
                    }`}
                  >
                    {s.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="pt-4 flex items-center justify-between gap-3">
              <button
                type="button"
                onClick={() => setCurrentStep(1)}
                className="px-5 py-3 border border-slate-300 text-slate-700 font-bold rounded-xl text-sm"
              >
                &larr; {language === 'mr' ? 'मागे' : 'Back'}
              </button>

              <button
                type="button"
                onClick={() => setCurrentStep(3)}
                className="px-8 py-3.5 bg-[#0f3b6c] hover:bg-[#0b2545] text-white font-bold rounded-xl text-base shadow-sm transition-all"
              >
                {language === 'mr' ? 'पुढील पायरी: वाइटल्स व फोटो' : 'Next: Vitals & Photo'} &rarr;
              </button>
            </div>
          </div>
        )}

        {/* Step 3: Vitals & Photo Upload */}
        {currentStep === 3 && (
          <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-sm space-y-6 max-w-3xl mx-auto">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-xl font-bold text-slate-900">{t.step3}</h3>
                <p className="text-xs text-slate-500">
                  {language === 'mr'
                    ? 'आशा भगिनींनी तपासलेले रक्तदाब/ताप आणि पूर्वीचे प्रिस्क्रिप्शन फोटो (पर्यायी)'
                    : 'Input clinical vitals taken by ASHA worker or patient, plus optional photo upload'}
                </p>
              </div>
              <Activity className="w-6 h-6 text-emerald-600" />
            </div>

            {/* Vitals Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200">
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  रक्तदाब (BP mmHg)
                </label>
                <input
                  type="text"
                  value={bp}
                  onChange={(e) => setBp(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm font-bold text-slate-900 text-center"
                  placeholder="120/80"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  नाडीचे ठोके (Pulse bpm)
                </label>
                <input
                  type="number"
                  value={pulse}
                  onChange={(e) => setPulse(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm font-bold text-slate-900 text-center"
                  placeholder="76"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  ऑक्सिजन (SpO2 %)
                </label>
                <input
                  type="number"
                  value={spo2}
                  onChange={(e) => setSpo2(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm font-bold text-slate-900 text-center"
                  placeholder="98"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  तापमान (Temp °F)
                </label>
                <input
                  type="text"
                  value={temperature}
                  onChange={(e) => setTemperature(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm font-bold text-slate-900 text-center"
                  placeholder="98.6"
                />
              </div>
            </div>

            {/* Photo / Old Prescription Upload */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                {language === 'mr' ? 'जुने औषध कागद किंवा जखमेचा फोटो जोडा (Photo Upload):' : 'Attach Photo / Previous Prescription:'}
              </label>
              <div
                onClick={() => setHasUploadedPhoto(!hasUploadedPhoto)}
                className={`border-2 border-dashed rounded-xl p-5 text-center cursor-pointer transition-all ${
                  hasUploadedPhoto
                    ? 'border-emerald-500 bg-emerald-50/60 text-emerald-900'
                    : 'border-slate-300 hover:border-blue-400 bg-slate-50 text-slate-600'
                }`}
              >
                {hasUploadedPhoto ? (
                  <div className="flex flex-col items-center">
                    <CheckCircle className="w-8 h-8 text-emerald-600 mb-1" />
                    <span className="font-bold text-sm">फोटो जोडला गेला आहे: old_prescription_scan.jpg</span>
                    <span className="text-xs text-slate-500 mt-1">काढण्यासाठी किंवा बदलण्यासाठी पुन्हा क्लिक करा</span>
                  </div>
                ) : (
                  <div className="flex flex-col items-center">
                    <Camera className="w-8 h-8 text-slate-400 mb-1" />
                    <span className="font-bold text-sm">कॅमेऱ्याने फोटो काढा किंवा फाइल निवडा</span>
                    <span className="text-xs text-slate-500 mt-0.5">
                      (कमी रिझोल्यूशनमध्ये स्वयंचलित कॉम्प्रेशन - 3G साठी अनुकूल)
                    </span>
                  </div>
                )}
              </div>
            </div>

            {/* Clinical Note */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {language === 'mr' ? 'तक्रारीचा अधिक तपशील (रुग्णाच्या शब्दात):' : 'Doctor Notes / Patient Description:'}
              </label>
              <textarea
                rows={2}
                value={clinicalNotes}
                onChange={(e) => setClinicalNotes(e.target.value)}
                className="w-full px-3.5 py-2.5 border border-slate-300 rounded-lg text-sm font-medium focus:ring-2 focus:ring-blue-600"
              />
            </div>

            {/* Low Bandwidth Guarantee Notice */}
            <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3 flex items-start gap-3 text-xs text-emerald-900">
              <Zap className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold block">3G / 2G नेटवर्क ऑप्टिमायझेशन</span>
                <span>
                  हा कॉल फक्त ३२ kbps बँडविड्थ वापरतो. जर इंटरनेट कमजोर असेल तर व्हिडिओ आपोआप थांबवून स्पष्ट व्हॉईस कॉल सुरू राहील.
                </span>
              </div>
            </div>

            <div className="pt-4 flex items-center justify-between gap-3">
              <button
                type="button"
                onClick={() => setCurrentStep(2)}
                className="px-5 py-3 border border-slate-300 text-slate-700 font-bold rounded-xl text-sm"
              >
                &larr; {language === 'mr' ? 'मागे' : 'Back'}
              </button>

              <button
                type="button"
                onClick={handleStartConsultation}
                className="px-8 py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-base shadow-md transition-all flex items-center gap-2 min-h-[50px]"
              >
                <Video className="w-5 h-5 text-white" />
                <span>{t.startCall}</span>
              </button>
            </div>
          </div>
        )}

        {/* Step 4: Live Low-Bandwidth Tele-Consultation Room */}
        {currentStep === 4 && (
          <div className="space-y-6">
            <div className="bg-slate-900 rounded-2xl overflow-hidden shadow-xl border border-slate-800 text-white">
              {/* Call Top Bar */}
              <div className="bg-slate-950 px-4 py-3 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-3 h-3 rounded-full bg-emerald-400 animate-ping"></div>
                  <div>
                    <span className="font-bold text-sm sm:text-base text-white block leading-tight">
                      {callConnected ? 'डॉ. अरविंद वाळवी (MD Family Medicine)' : 'सरकारी डॉक्टरांशी संपर्क जोडत आहे...'}
                    </span>
                    <span className="text-[11px] text-slate-400">
                      उपजिल्हा रुग्णालय नंदुरबार / टेलिमेडिसीन नोड · Reg No: MMC-2014-9812
                    </span>
                  </div>
                </div>

                {/* Bandwidth Monitor & Quality Switch */}
                <div className="flex items-center gap-2 text-xs">
                  <span className="bg-slate-800 text-slate-300 px-2.5 py-1 rounded-md border border-slate-700 font-mono">
                    {lowBandwidthVoiceOnly ? 'Voice-Only 32 kbps' : 'Adaptive 3G Video (128 kbps)'}
                  </span>

                  <button
                    onClick={() => setLowBandwidthVoiceOnly(!lowBandwidthVoiceOnly)}
                    className={`px-2.5 py-1 rounded-md font-bold transition-colors ${
                      lowBandwidthVoiceOnly ? 'bg-amber-600 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                    }`}
                  >
                    {lowBandwidthVoiceOnly ? 'डेटा सेव्हर सुरू (Voice)' : 'व्हिडिओ चालू'}
                  </button>
                </div>
              </div>

              {/* Video Window Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 p-4 min-h-[380px] sm:min-h-[440px] items-center">
                {/* Doctor's Video Screen */}
                <div className="lg:col-span-8 relative bg-slate-950 rounded-xl overflow-hidden border border-slate-800 h-full flex flex-col justify-center items-center min-h-[300px]">
                  {callConnected ? (
                    !lowBandwidthVoiceOnly ? (
                      <img
                        src={teleDoctorImg}
                        alt="Government Doctor Video Stream"
                        className="w-full h-full max-h-[380px] object-cover"
                      />
                    ) : (
                      <div className="text-center p-6 space-y-3">
                        <div className="w-20 h-20 rounded-full bg-blue-900/60 border-2 border-blue-400 flex items-center justify-center mx-auto text-3xl font-bold text-blue-200">
                          डॉ
                        </div>
                        <h4 className="font-bold text-lg text-white">डॉ. अरविंद वाळवी बोलत आहेत</h4>
                        <p className="text-xs text-slate-400 max-w-sm mx-auto">
                          अशक्त इंटरनेटमुळे व्हिडिओ ऐवजी अति-स्पष्ट ऑडिओ सुरू आहे. आपला आवाज डॉक्टरपर्यंत व्यवस्थित पोहोचत आहे.
                        </p>
                        <div className="flex justify-center items-center gap-1 text-emerald-400 font-mono text-xs">
                          <span className="w-1.5 h-4 bg-emerald-500 animate-pulse rounded-full"></span>
                          <span className="w-1.5 h-7 bg-emerald-400 animate-pulse rounded-full delay-75"></span>
                          <span className="w-1.5 h-5 bg-emerald-500 animate-pulse rounded-full delay-150"></span>
                          <span className="w-1.5 h-8 bg-emerald-300 animate-pulse rounded-full"></span>
                          <span className="ml-2">Live Audio Active</span>
                        </div>
                      </div>
                    )
                  ) : (
                    <div className="text-center p-8 space-y-3">
                      <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto"></div>
                      <p className="font-bold text-slate-200">उपलब्ध शासकीय वैद्यकीय अधिकाऱ्याशी जोडत आहे...</p>
                      <p className="text-xs text-slate-400">प्रतीक्षा वेळ: ~१ मिनिट</p>
                    </div>
                  )}

                  {/* Patient Self-View PiP */}
                  <div className="absolute bottom-3 right-3 w-28 h-20 bg-slate-800 rounded-lg border border-slate-600 overflow-hidden flex items-center justify-center text-xs text-slate-400 shadow-lg">
                    {isVideoOff ? (
                      <div className="flex flex-col items-center text-[10px]">
                        <VideoOff className="w-4 h-4 text-red-400" />
                        <span>कॅमेरा बंद</span>
                      </div>
                    ) : (
                      <div className="bg-slate-700 w-full h-full flex flex-col items-center justify-center text-white">
                        <User className="w-6 h-6 text-slate-300" />
                        <span className="text-[9px] font-medium">{patientName.split(' ')[0]}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Right: Live Clinical Triage & Prescription Panel */}
                <div className="lg:col-span-4 bg-slate-950/80 border border-slate-800 rounded-xl p-4 flex flex-col justify-between h-full space-y-3">
                  <div>
                    <span className="text-[11px] font-bold text-blue-400 uppercase tracking-wider block mb-1">
                      रुग्ण सारांश (Patient Case Sheet)
                    </span>
                    <h4 className="font-bold text-white text-base leading-snug">
                      {patientName} ({patientAge} वर्षे / {patientGender === 'Female' ? 'स्त्री' : 'पुरुष'})
                    </h4>
                    <p className="text-xs text-slate-400">{village}</p>

                    <div className="mt-3 bg-slate-900 p-2.5 rounded-lg border border-slate-800 text-xs space-y-1">
                      <div className="flex justify-between text-slate-300">
                        <span className="text-slate-400">रक्तदाब:</span>
                        <span className="font-bold text-white">{bp} mmHg</span>
                      </div>
                      <div className="flex justify-between text-slate-300">
                        <span className="text-slate-400">तापमान:</span>
                        <span className="font-bold text-amber-400">{temperature} °F</span>
                      </div>
                      <div className="flex justify-between text-slate-300">
                        <span className="text-slate-400">SpO2:</span>
                        <span className="font-bold text-emerald-400">{spo2}%</span>
                      </div>
                    </div>

                    <div className="mt-2.5">
                      <span className="text-[11px] text-slate-400 font-semibold block mb-1">लक्षणे:</span>
                      <div className="flex flex-wrap gap-1">
                        {selectedSymptoms.map((s, i) => (
                          <span key={i} className="text-[10px] bg-slate-800 text-slate-200 px-2 py-0.5 rounded border border-slate-700">
                            {s}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Doctor Prescription Actions */}
                  <div className="pt-2 border-t border-slate-800 space-y-2">
                    {!prescriptionIssued ? (
                      <button
                        onClick={() => setPrescriptionIssued(true)}
                        className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition-colors flex items-center justify-center gap-1.5 shadow-sm"
                      >
                        <FileText className="w-4 h-4" />
                        <span>डॉक्टरांचे डिजिटल ई-प्रिस्क्रिप्शन जारी करा</span>
                      </button>
                    ) : (
                      <div className="bg-emerald-950/60 border border-emerald-700 p-2.5 rounded-lg text-emerald-300 text-xs flex items-center justify-between">
                        <span className="font-bold">✓ ई-प्रिस्क्रिप्शन तयार झाले!</span>
                        <button
                          onClick={handlePrintPrescription}
                          className="bg-emerald-700 hover:bg-emerald-600 text-white px-2 py-1 rounded text-[11px] font-bold flex items-center gap-1"
                        >
                          <Printer className="w-3 h-3" />
                          <span>प्रिंट</span>
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Call Controls Bar (Large buttons for rural touchscreens) */}
              <div className="bg-slate-950 p-4 border-t border-slate-800 flex items-center justify-center gap-4">
                <button
                  onClick={() => setIsMuted(!isMuted)}
                  className={`w-12 h-12 rounded-full flex items-center justify-center transition-colors ${
                    isMuted ? 'bg-red-600 text-white' : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
                  }`}
                  title="Mute / Unmute Audio"
                >
                  {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                </button>

                <button
                  onClick={() => setIsVideoOff(!isVideoOff)}
                  className={`w-12 h-12 rounded-full flex items-center justify-center transition-colors ${
                    isVideoOff ? 'bg-red-600 text-white' : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
                  }`}
                  title="Camera On / Off"
                >
                  {isVideoOff ? <VideoOff className="w-5 h-5" /> : <Video className="w-5 h-5" />}
                </button>

                <button
                  onClick={() => {
                    setCallConnected(false);
                    setCurrentStep(1);
                  }}
                  className="px-6 h-12 rounded-full bg-red-600 hover:bg-red-700 text-white font-bold flex items-center gap-2 shadow-lg transition-colors"
                >
                  <PhoneOff className="w-5 h-5" />
                  <span>कॉल समाप्त (End Call)</span>
                </button>
              </div>
            </div>

            {/* Printable Digital Prescription Slip */}
            {prescriptionIssued && (
              <div
                id="printable-prescription"
                className="bg-white rounded-2xl border-2 border-blue-900 p-6 sm:p-8 shadow-md text-slate-900 space-y-4 max-w-3xl mx-auto"
              >
                {/* Official Govt Letterhead */}
                <div className="border-b-2 border-blue-900 pb-3 flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <span className="text-xs font-bold text-blue-900 uppercase tracking-wide">
                      महाराष्ट्र शासन · सार्वजनिक आरोग्य विभाग
                    </span>
                    <h3 className="text-xl font-extrabold text-[#0b2545]">
                      ई-संजीवनी डिजिटल प्रिस्क्रिप्शन स्लिप (e-Prescription)
                    </h3>
                    <p className="text-xs text-slate-600">
                      National Tele-Consultation Service · PHC / CHC Remote Node
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="text-xs font-mono font-bold bg-blue-100 text-blue-900 px-2 py-0.5 rounded">
                      Rx No: MH-TELE-2026-{Math.floor(100000 + Math.random() * 900000)}
                    </span>
                    <span className="text-[11px] text-slate-500 block mt-1">
                      तारीख: {new Date().toLocaleDateString('mr-IN')}
                    </span>
                  </div>
                </div>

                {/* Patient & Doctor Meta */}
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs bg-slate-50 p-3 rounded-lg border border-slate-200">
                  <div>
                    <span className="text-slate-500 block">रुग्णाचे नाव:</span>
                    <span className="font-bold text-slate-900 text-sm">{patientName}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">वय व लिंग:</span>
                    <span className="font-bold text-slate-900">{patientAge} वर्षे / {patientGender}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">गाव / तालुका:</span>
                    <span className="font-bold text-slate-900">{village}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">सल्लागार डॉक्टर:</span>
                    <span className="font-bold text-slate-900">Dr. Arvind Valvi (MBBS, DCH)</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">नोंदणी क्रमांक:</span>
                    <span className="font-bold text-slate-900">MMC-2014-9812</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">आरोग्य केंद्र:</span>
                    <span className="font-bold text-slate-900">Nandurbar Sub-District Telemed Hub</span>
                  </div>
                </div>

                {/* Prescribed Free Medicines (Directly matching government dispensary stock) */}
                <div>
                  <h4 className="font-bold text-sm text-slate-900 flex items-center gap-1.5 mb-2">
                    <span className="text-base text-blue-800 font-serif font-black">℞</span>
                    <span>विहित केलेली मोफत औषधे (Free Government Medicines to collect at PHC):</span>
                  </h4>
                  <div className="border border-slate-200 rounded-lg overflow-hidden text-xs">
                    <table className="w-full text-left">
                      <thead className="bg-slate-100 font-bold text-slate-700 border-b border-slate-200">
                        <tr>
                          <th className="p-2">औषधाचे नाव (Medicine)</th>
                          <th className="p-2">मात्रा (Dosage)</th>
                          <th className="p-2">कालावधी (Duration)</th>
                          <th className="p-2">सूचना (Instructions)</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200">
                        <tr>
                          <td className="p-2 font-bold text-slate-900">Tab. Paracetamol IP 500 mg</td>
                          <td className="p-2">१ गोळी (सकाळी - दुपारी - रात्री)</td>
                          <td className="p-2">५ दिवस</td>
                          <td className="p-2 text-slate-600">जेवणानंतर, तापासाठी</td>
                        </tr>
                        <tr>
                          <td className="p-2 font-bold text-slate-900">Cap. Amoxicillin 500 mg</td>
                          <td className="p-2">१ गोळी (सकाळी - रात्री)</td>
                          <td className="p-2">५ दिवस</td>
                          <td className="p-2 text-slate-600">कोमट पाण्यासोबत, कोर्स पूर्ण करा</td>
                        </tr>
                        <tr>
                          <td className="p-2 font-bold text-slate-900">ORS Sachet (जीवन जल)</td>
                          <td className="p-2">१ लिटर पाण्यात विरघळून</td>
                          <td className="p-2">३ दिवस</td>
                          <td className="p-2 text-slate-600">वारंवार थोडे थोडे पाणी प्या</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Special Instructions & QR */}
                <div className="flex flex-wrap items-center justify-between gap-4 pt-3 border-t border-slate-200 text-xs">
                  <div className="max-w-md text-slate-600">
                    <p className="font-bold text-slate-800">सूचना / सल्ला:</p>
                    <p>भरपूर उकळून थंड केलेले पाणी प्या. ताप न उतरल्यास त्वरित जवळच्या प्राथमिक आरोग्य केंद्रात प्रत्यक्ष भेट द्या.</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-16 h-16 bg-slate-100 border border-slate-300 rounded flex items-center justify-center text-[10px] text-center font-mono">
                      [QR Code Verified]
                    </div>
                    <div className="text-right">
                      <div className="w-24 h-8 border-b border-slate-400 inline-block"></div>
                      <span className="block text-[11px] font-bold text-slate-700">डॉक्टरांची डिजिटल स्वाक्षरी</span>
                      <span className="block text-[10px] text-emerald-700 font-bold">✓ e-Signed DHS Maharashtra</span>
                    </div>
                  </div>
                </div>

                {/* Action to Print or Save PDF */}
                <div className="pt-2 flex justify-end gap-2 print:hidden">
                  <button
                    onClick={handlePrintPrescription}
                    className="px-5 py-2.5 bg-[#0f3b6c] hover:bg-[#0b2545] text-white rounded-lg text-xs font-bold flex items-center gap-2 shadow-xs"
                  >
                    <Printer className="w-4 h-4" />
                    <span>{t.downloadRx}</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </section>
  );
};
