import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import ashaWorkerImg from '../assets/images/asha_health_worker_1790169654131.jpg';
import { REGIONAL_ALERTS } from '../data/mockData';
import {
  Users,
  Shield,
  WifiOff,
  Wifi,
  RefreshCw,
  PlusCircle,
  CheckCircle2,
  AlertTriangle,
  TrendingUp,
  Activity,
  FileCheck,
  Stethoscope,
  BarChart3,
  Calendar,
  Layers,
  MapPin,
} from 'lucide-react';

export const AshaAdminDashboard: React.FC = () => {
  const {
    ashaRecords,
    addAshaRecord,
    syncPendingRecords,
    pendingSyncCount,
    networkMode,
    setNetworkMode,
    facilities,
    grievances,
    language,
    t,
  } = useApp();

  const [activePortalRole, setActivePortalRole] = useState<'asha' | 'admin'>('asha');

  // ASHA field form states
  const [patientName, setPatientName] = useState('');
  const [village, setVillage] = useState('घोडकेवाडी पाडा');
  const [recordType, setRecordType] = useState<'ANC (Maternal)' | 'Child Immunization' | 'SAM/MAM Nutrition' | 'Fever/Malaria Survey'>('ANC (Maternal)');
  const [details, setDetails] = useState('');
  const [formSuccess, setFormSuccess] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);

  const handleAddRecord = (e: React.FormEvent) => {
    e.preventDefault();
    if (!patientName.trim()) return;

    addAshaRecord({
      patientName,
      village,
      recordType,
      details: details || 'Routine survey completed; basic vitals recorded.',
      visitDate: new Date().toISOString().split('T')[0],
    });

    setPatientName('');
    setDetails('');
    setFormSuccess(true);
    setTimeout(() => setFormSuccess(false), 3000);
  };

  const handleManualSync = async () => {
    setIsSyncing(true);
    await syncPendingRecords();
    setIsSyncing(false);
  };

  // Admin calculations
  const totalBedsStatewide = facilities.reduce((sum, f) => sum + f.totalBeds, 0);
  const availableBedsStatewide = facilities.reduce((sum, f) => sum + f.availableBeds, 0);
  const avgCleanliness = (
    facilities.reduce((sum, f) => sum + f.cleanlinessScore, 0) / facilities.length
  ).toFixed(1);

  return (
    <section className="py-10 bg-slate-50 border-b border-slate-200" id="asha-admin">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Switcher: ASHA Worker vs DHS Admin Console */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-8 border-b border-slate-200 pb-5">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-100 text-blue-900 text-xs font-semibold mb-1">
              <Shield className="w-3.5 h-3.5 text-blue-700" />
              <span>{language === 'mr' ? 'आरोग्य कर्मचारी व प्रशासन नियंत्रण कक्ष' : 'Healthcare Worker & Administration'}</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-[#0b2545]">
              {activePortalRole === 'asha' ? t.portalSwitchAsha : t.portalSwitchAdmin}
            </h2>
          </div>

          <div className="flex items-center bg-slate-200 p-1 rounded-xl border border-slate-300">
            <button
              onClick={() => setActivePortalRole('asha')}
              className={`px-4 py-2 rounded-lg text-xs sm:text-sm font-bold transition-all ${
                activePortalRole === 'asha'
                  ? 'bg-blue-800 text-white shadow-xs'
                  : 'text-slate-700 hover:text-slate-900'
              }`}
            >
              👩‍⚕️ आशा भगिनी पोर्टल (Field Mode)
            </button>
            <button
              onClick={() => setActivePortalRole('admin')}
              className={`px-4 py-2 rounded-lg text-xs sm:text-sm font-bold transition-all ${
                activePortalRole === 'admin'
                  ? 'bg-blue-800 text-white shadow-xs'
                  : 'text-slate-700 hover:text-slate-900'
              }`}
            >
              📊 जिल्हा प्रशासन (DHS Admin)
            </button>
          </div>
        </div>

        {/* Offline Sync Status Banner (Prompt Technical Constraint) */}
        <div
          className={`mb-6 p-4 rounded-xl border flex flex-wrap items-center justify-between gap-4 transition-colors ${
            networkMode === 'offline'
              ? 'bg-amber-50 border-amber-300 text-amber-900'
              : pendingSyncCount > 0
              ? 'bg-blue-50 border-blue-200 text-blue-900'
              : 'bg-emerald-50 border-emerald-200 text-emerald-900'
          }`}
        >
          <div className="flex items-center gap-3">
            <div
              className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                networkMode === 'offline'
                  ? 'bg-amber-200 text-amber-900'
                  : 'bg-white text-blue-800 shadow-xs'
              }`}
            >
              {networkMode === 'offline' ? (
                <WifiOff className="w-5 h-5 text-amber-800 animate-pulse" />
              ) : (
                <Wifi className="w-5 h-5 text-emerald-600" />
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-sm">
                  {networkMode === 'offline' ? 'ऑफलाइन मोड सक्रिय (Offline Mode Active)' : 'ऑनलाइन नेटवर्क जोडणी सक्रिय (Online)'}
                </span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-white/80 border border-current">
                  PWA Local Storage
                </span>
              </div>
              <p className="text-xs mt-0.5 opacity-90">
                {networkMode === 'offline'
                  ? t.offlineWarning
                  : pendingSyncCount > 0
                  ? `${pendingSyncCount} नवीन रुग्ण नोंदणी सर्व्हरवर सिंक होणे बाकी आहे.`
                  : 'सर्व रुग्ण नोंदी राज्य आरोग्य डेटाबेसशी सुसंगत व सुरक्षित आहेत.'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleManualSync}
              disabled={isSyncing || networkMode === 'offline'}
              className={`px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-2 shadow-xs transition-all ${
                networkMode === 'offline'
                  ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                  : 'bg-blue-700 hover:bg-blue-800 text-white'
              }`}
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
              <span>{isSyncing ? 'सिंक होत आहे...' : t.forceSync} ({pendingSyncCount})</span>
            </button>
          </div>
        </div>

        {/* ROLE 1: ASHA Field Worker Portal */}
        {activePortalRole === 'asha' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left: Quick Field Record Entry */}
            <div className="lg:col-span-6 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
                <div>
                  <h3 className="font-bold text-slate-900 text-lg">
                    {t.logPatientRecord}
                  </h3>
                  <p className="text-xs text-slate-500">
                    आशा कार्यकर्ता: सुनीता कांबळे (ID: ASHA-PUN-4091)
                  </p>
                </div>
                <div className="w-10 h-10 rounded-full overflow-hidden border border-slate-200">
                  <img src={ashaWorkerImg} alt="ASHA Worker" className="w-full h-full object-cover" />
                </div>
              </div>

              {formSuccess && (
                <div className="mb-4 bg-emerald-50 border border-emerald-300 text-emerald-900 p-3 rounded-xl text-xs flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>नोंद स्थानिक मेमरीमध्ये सेव्ह झाली! इंटरनेट उपलब्ध झाल्यावर आपोआप सिंक होईल.</span>
                </div>
              )}

              <form onSubmit={handleAddRecord} className="space-y-4 text-xs sm:text-sm">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    रुग्णाचे नाव व वय (Patient Full Name) *
                  </label>
                  <input
                    type="text"
                    required
                    value={patientName}
                    onChange={(e) => setPatientName(e.target.value)}
                    placeholder="उदा. मंदाबाई तुकाराम कोकरे (वय २६)"
                    className="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-slate-900 font-medium focus:ring-2 focus:ring-blue-600"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      गाव / पाडा (Village / Hamlet) *
                    </label>
                    <input
                      type="text"
                      required
                      value={village}
                      onChange={(e) => setVillage(e.target.value)}
                      className="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-slate-900 font-medium focus:ring-2 focus:ring-blue-600"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      तपासणी वर्गवारी (Record Type) *
                    </label>
                    <select
                      value={recordType}
                      onChange={(e) => setRecordType(e.target.value as any)}
                      className="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-slate-900 font-medium bg-white"
                    >
                      <option value="ANC (Maternal)">ANC गरोदर माता तपासणी</option>
                      <option value="Child Immunization">बालक लसीकरण (Immunization)</option>
                      <option value="SAM/MAM Nutrition">कुपोषण (SAM/MAM Nutrition)</option>
                      <option value="Fever/Malaria Survey">ताप / मलेरिया रक्तनमुना</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    तपासणी निष्कर्ष व दिलेली औषधे (Clinical Details)
                  </label>
                  <textarea
                    rows={3}
                    value={details}
                    onChange={(e) => setDetails(e.target.value)}
                    placeholder="उदा. रक्तदाब ११०/७०, वजन ५२ किलो, ६० आयएफए गोळ्या वाटप, पुढची तपासणी १५ ऑक्टोबर..."
                    className="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-slate-900 font-medium focus:ring-2 focus:ring-blue-600"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-[#0f3b6c] hover:bg-[#0b2545] text-white font-bold rounded-xl text-sm shadow-sm transition-all flex items-center justify-center gap-2 min-h-[46px]"
                >
                  <PlusCircle className="w-4 h-4 text-emerald-300" />
                  <span>नोंद साठवा (Save Record Offline)</span>
                </button>
              </form>
            </div>

            {/* Right: Offline Registered Records List */}
            <div className="lg:col-span-6 space-y-4">
              <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
                  <div>
                    <h3 className="font-bold text-slate-900 text-base">
                      नोंदवलेले रुग्ण रेकॉर्ड्स ({ashaRecords.length})
                    </h3>
                    <span className="text-xs text-slate-500">
                      गावातील प्रत्यक्ष आरोग्य तपासणी यादी
                    </span>
                  </div>
                  <span className="text-xs bg-blue-50 text-blue-800 font-bold px-2.5 py-1 rounded-full border border-blue-200">
                    ग्राम आरोग्य रजिस्टर
                  </span>
                </div>

                <div className="space-y-3 max-h-[460px] overflow-y-auto pr-1">
                  {ashaRecords.map((rec) => (
                    <div
                      key={rec.id}
                      className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/70 text-xs space-y-1.5"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-900 text-sm">
                          {rec.patientName}
                        </span>
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            rec.synced
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-amber-100 text-amber-800 animate-pulse'
                          }`}
                        >
                          {rec.synced ? '✓ सिंक झाले' : '⏳ सिंक बाकी'}
                        </span>
                      </div>

                      <div className="flex items-center gap-2 text-slate-500 font-medium">
                        <span className="bg-blue-100 text-blue-900 px-1.5 py-0.2 rounded text-[10px] font-bold">
                          {rec.recordType}
                        </span>
                        <span>·</span>
                        <span>{rec.village}</span>
                        <span>·</span>
                        <span>{rec.visitDate}</span>
                      </div>

                      <p className="text-slate-700 font-normal leading-relaxed pt-1">
                        {rec.details}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ROLE 2: State / District Health Administration (DHS Admin) */}
        {activePortalRole === 'admin' && (
          <div className="space-y-6">
            {/* 4 High-Level District Metrics */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
                <span className="text-xs font-bold text-slate-500 block uppercase">
                  {language === 'mr' ? 'जोडलेली प्राथमिक आरोग्य केंद्रे' : 'Active PHC/CHC Nodes'}
                </span>
                <span className="text-2xl sm:text-3xl font-extrabold text-[#0b2545] mt-1 block">
                  3,240
                </span>
                <span className="text-[11px] text-emerald-700 font-bold flex items-center gap-1 mt-1">
                  <TrendingUp className="w-3 h-3" />
                  +12 नवीन सेंटर्स जोडली गेली
                </span>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
                <span className="text-xs font-bold text-slate-500 block uppercase">
                  {t.doctorAttendance}
                </span>
                <span className="text-2xl sm:text-3xl font-extrabold text-emerald-700 mt-1 block">
                  92.4%
                </span>
                <span className="text-[11px] text-slate-500 block mt-1">
                  बायोमेट्रिक व जिओ-फेंस पडताळणी
                </span>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
                <span className="text-xs font-bold text-slate-500 block uppercase">
                  {t.citizenSatisfaction}
                </span>
                <span className="text-2xl sm:text-3xl font-extrabold text-blue-700 mt-1 block">
                  {avgCleanliness} / 5.0
                </span>
                <span className="text-[11px] text-slate-500 block mt-1">
                  {grievances.length} नागरिकांनी अभिप्राय नोंदवले
                </span>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
                <span className="text-xs font-bold text-slate-500 block uppercase">
                  उपलब्ध खाटा (Hospital Beds)
                </span>
                <span className="text-2xl sm:text-3xl font-extrabold text-purple-700 mt-1 block">
                  {availableBedsStatewide} / {totalBedsStatewide}
                </span>
                <span className="text-[11px] text-emerald-700 font-bold block mt-1">
                  २४x७ प्रसूती व आयसीयू सज्ज
                </span>
              </div>
            </div>

            {/* Regional Health Alerts & Facility Overview */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Regional Epidemic / Supply Alerts */}
              <div className="lg:col-span-6 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="w-5 h-5 text-amber-600" />
                    <h3 className="font-bold text-slate-900 text-base">
                      {t.outbreakAlert} (Real-time DHS Alerts)
                    </h3>
                  </div>
                  <span className="text-[11px] font-bold bg-red-100 text-red-800 px-2.5 py-0.5 rounded-full">
                    ३ सक्रिय इशारे
                  </span>
                </div>

                <div className="space-y-3">
                  {REGIONAL_ALERTS.map((alt) => (
                    <div
                      key={alt.id}
                      className={`p-3.5 rounded-xl border text-xs space-y-1 ${
                        alt.severity === 'High'
                          ? 'bg-rose-50 border-rose-200 text-rose-950'
                          : alt.severity === 'Medium'
                          ? 'bg-amber-50 border-amber-200 text-amber-950'
                          : 'bg-blue-50 border-blue-200 text-blue-950'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-sm">
                          {language === 'mr' ? alt.titleMr : alt.title}
                        </span>
                        <span className="font-semibold text-[10px] uppercase px-1.5 py-0.5 rounded bg-white/70">
                          {alt.district}
                        </span>
                      </div>
                      <p className="opacity-90 leading-relaxed">{alt.description}</p>
                      <span className="text-[10px] opacity-75 block">दिनांक: {alt.date}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* PHC Quality & Cleanliness Rank Table */}
              <div className="lg:col-span-6 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <div className="flex items-center gap-2">
                    <BarChart3 className="w-5 h-5 text-blue-700" />
                    <h3 className="font-bold text-slate-900 text-base">
                      प्राथमिक आरोग्य केंद्र गुणवत्ता रँकिंग
                    </h3>
                  </div>
                  <span className="text-xs text-slate-500 font-semibold">कायपालकल्प योजना</span>
                </div>

                <div className="space-y-2 text-xs">
                  {facilities.map((fac) => (
                    <div
                      key={fac.id}
                      className="p-2.5 rounded-lg border border-slate-100 bg-slate-50 flex items-center justify-between hover:bg-slate-100 transition-colors"
                    >
                      <div>
                        <span className="font-bold text-slate-900 block">
                          {fac.name}
                        </span>
                        <span className="text-[11px] text-slate-500">
                          {fac.district} · {fac.taluka}
                        </span>
                      </div>

                      <div className="text-right">
                        <span className="font-bold text-amber-700 text-sm block">
                          ★ {fac.cleanlinessScore} / 5
                        </span>
                        <span className="text-[10px] text-emerald-700 font-medium">
                          {fac.deliveryFacility24x7 ? '२४x७ प्रसूती' : 'ओपीडी'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
