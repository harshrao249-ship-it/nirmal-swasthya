import React from 'react';
import { useApp } from '../context/AppContext';
import { Phone, Shield, Heart, Activity, Globe, CheckCircle } from 'lucide-react';

export const Footer: React.FC = () => {
  const { language, t, setActiveTab } = useApp();

  return (
    <footer className="bg-[#07172b] text-white border-t-4 border-amber-500 pt-12 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 pb-8 border-b border-slate-800">
          {/* Col 1: Government Identity */}
          <div className="space-y-3">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-blue-700/60 border border-blue-400/40 flex items-center justify-center text-white font-bold">
                <Activity className="w-6 h-6 text-emerald-300" />
              </div>
              <div>
                <span className="font-extrabold text-lg text-white block leading-tight">
                  {t.portalName}
                </span>
                <span className="text-xs text-slate-400 block">
                  {t.deptTitle}, {t.govTitle}
                </span>
              </div>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              {t.tagline} - डिजिटल इंडिया व राष्ट्रीय आरोग्य अभियानांतर्गत (NHM) ग्रामीण महाराष्ट्रातील जनतेसाठी मोफत डिजिटल आरोग्य प्लॅटफॉर्म.
            </p>
            <div className="text-[11px] text-amber-400 font-semibold">
              ✓ Smart India Hackathon (SIH) Citizen Health Initiative
            </div>
          </div>

          {/* Col 2: Citizen Emergency Helplines */}
          <div className="space-y-3">
            <h4 className="font-bold text-sm text-amber-400 uppercase tracking-wider">
              {t.emergencyHelpline} (Toll-Free 24x7)
            </h4>
            <ul className="space-y-2 text-xs text-slate-300">
              <li>
                <a href="tel:108" className="flex items-center gap-2 hover:text-white font-bold text-amber-300">
                  <Phone className="w-3.5 h-3.5 text-red-400" />
                  <span>१०८ - आपत्कालीन रुग्णवाहिका (Ambulance)</span>
                </a>
              </li>
              <li>
                <a href="tel:104" className="flex items-center gap-2 hover:text-white font-medium">
                  <Phone className="w-3.5 h-3.5 text-blue-400" />
                  <span>१०४ - मोफत शासकीय आरोग्य सल्ला (Health Advice)</span>
                </a>
              </li>
              <li>
                <a href="tel:181" className="flex items-center gap-2 hover:text-white font-medium">
                  <Phone className="w-3.5 h-3.5 text-pink-400" />
                  <span>१८१ - महिला सहाय्यता व समुपदेशन (Women Helpline)</span>
                </a>
              </li>
              <li>
                <a href="tel:1098" className="flex items-center gap-2 hover:text-white font-medium">
                  <Phone className="w-3.5 h-3.5 text-emerald-400" />
                  <span>१०९८ - बाल रक्षक सहाय्यता (Childline 24x7)</span>
                </a>
              </li>
            </ul>
          </div>

          {/* Col 3: Quick Navigation */}
          <div className="space-y-3">
            <h4 className="font-bold text-sm text-amber-400 uppercase tracking-wider">
              पोर्टल प्रमुख दुवे
            </h4>
            <ul className="space-y-1.5 text-xs text-slate-300">
              <li>
                <button onClick={() => setActiveTab('locator')} className="hover:text-amber-300 transition-colors">
                  &bull; {t.navLocator} (PHC Locator)
                </button>
              </li>
              <li>
                <button onClick={() => setActiveTab('telemed')} className="hover:text-amber-300 transition-colors">
                  &bull; {t.navTelemed} (Low-BW Doctor Call)
                </button>
              </li>
              <li>
                <button onClick={() => setActiveTab('medicines')} className="hover:text-amber-300 transition-colors">
                  &bull; {t.navMedicine} (Essential Medicine Stock)
                </button>
              </li>
              <li>
                <button onClick={() => setActiveTab('grievance')} className="hover:text-amber-300 transition-colors">
                  &bull; {t.navGrievance} (Quality Rating & Feedback)
                </button>
              </li>
              <li>
                <button onClick={() => setActiveTab('asha-admin')} className="hover:text-amber-300 transition-colors">
                  &bull; {t.navAshaAdmin} (ASHA Offline Register)
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Standards & Accessibility Compliance */}
          <div className="space-y-3">
            <h4 className="font-bold text-sm text-amber-400 uppercase tracking-wider">
              डिजिटल मानके व सुलभता
            </h4>
            <div className="space-y-2 text-xs text-slate-400 leading-relaxed">
              <p>
                हे पोर्टल सर्व वयोगटांसाठी, ज्येष्ठ नागरिक व दृष्टिहीन व्यक्तींसाठी अनुकूलित (W3C WCAG 2.1 AA Compliant) बनवले आहे.
              </p>
              <div className="flex flex-wrap gap-1 pt-1">
                <span className="bg-slate-800 text-slate-300 px-2 py-0.5 rounded text-[10px] border border-slate-700">
                  GIGW 3.0 Certified
                </span>
                <span className="bg-slate-800 text-slate-300 px-2 py-0.5 rounded text-[10px] border border-slate-700">
                  PWA Offline Ready
                </span>
                <span className="bg-slate-800 text-slate-300 px-2 py-0.5 rounded text-[10px] border border-slate-700">
                  3G Data Saver
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom copyright & disclaimer */}
        <div className="flex flex-col sm:flex-row items-center justify-between text-xs text-slate-400 gap-3">
          <p>
            © {new Date().getFullYear()} सार्वजनिक आरोग्य विभाग, महाराष्ट्र शासन (Government of Maharashtra). सर्व हक्क राखीव.
          </p>
          <div className="flex items-center gap-4 text-[11px]">
            <span className="hover:underline cursor-pointer">नागरिक सनद (Citizen Charter)</span>
            <span>·</span>
            <span className="hover:underline cursor-pointer">गोपनीयता धोरण</span>
            <span>·</span>
            <span className="hover:underline cursor-pointer">वापर अटी</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
