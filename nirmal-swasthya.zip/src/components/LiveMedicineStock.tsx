import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { MedicineItem } from '../types';
import {
  Search,
  Pill,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  BellRing,
  Building2,
  Calendar,
  Filter,
  ShieldCheck,
  Check,
} from 'lucide-react';

export const LiveMedicineStock: React.FC = () => {
  const { medicines, language, t } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [alertModalMed, setAlertModalMed] = useState<MedicineItem | null>(null);
  const [alertSubscribed, setAlertSubscribed] = useState(false);
  const [subscriberPhone, setSubscriberPhone] = useState('9823123456');

  const categories = [
    'All',
    'Antibiotic',
    'Analgesic',
    'Maternal Health',
    'Chronic Care',
    'Emergency',
    'Vaccine/Serum',
  ];

  const filteredMeds = medicines.filter((med) => {
    if (selectedCategory !== 'All' && med.category !== selectedCategory) return false;
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      const matchGen = med.genericName.toLowerCase().includes(q);
      const matchBrand = med.brandName.toLowerCase().includes(q);
      const matchMr = med.nameMr.toLowerCase().includes(q);
      const matchLoc = med.phcLocation.toLowerCase().includes(q);
      if (!matchGen && !matchBrand && !matchMr && !matchLoc) return false;
    }
    return true;
  });

  const handleOpenAlert = (med: MedicineItem) => {
    setAlertModalMed(med);
    setAlertSubscribed(false);
  };

  return (
    <section className="py-10 bg-slate-50 border-b border-slate-200" id="medicine-finder">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="mb-8 text-center sm:text-left">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-100 text-amber-900 text-xs font-semibold mb-2">
            <Pill className="w-3.5 h-3.5 text-amber-700" />
            <span>
              {language === 'mr' ? 'मोफत शासकीय औषधालय' : 'Haffkine & DHS Live Inventory'}
            </span>
          </div>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-[#0b2545] tracking-tight">
            {t.medicineTitle}
          </h2>
          <p className="text-slate-600 mt-2 text-sm sm:text-base max-w-3xl">
            {t.medicineSubtitle}
          </p>
        </div>

        {/* Search and Category Filter Box */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm mb-6 space-y-4">
          <div className="relative">
            <Search className="w-5 h-5 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder={t.searchMedsPlaceholder}
              className="w-full pl-10 pr-4 py-3.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-blue-600 text-sm font-medium text-slate-900"
            />
          </div>

          {/* Categories Pill Buttons */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
            <span className="text-slate-500 font-semibold shrink-0 mr-1 flex items-center gap-1">
              <Filter className="w-3.5 h-3.5" />
              {language === 'mr' ? 'वर्गवारी:' : 'Category:'}
            </span>
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors ${
                  selectedCategory === cat
                    ? 'bg-[#0f3b6c] text-white'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                {cat === 'All'
                  ? language === 'mr' ? 'सर्व औषधे' : 'All Medicines'
                  : cat === 'Maternal Health'
                  ? language === 'mr' ? 'माता व बाल संगोपन' : 'Maternal Care'
                  : cat === 'Chronic Care'
                  ? language === 'mr' ? 'बीपी/डायबिटीस (NCD)' : 'Chronic Care'
                  : cat === 'Emergency'
                  ? language === 'mr' ? 'सर्पदंश / आपत्कालीन' : 'Emergency'
                  : cat}
              </button>
            ))}
          </div>
        </div>

        {/* Live Medicine Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredMeds.map((med) => {
            const isStockIn = med.stockStatus === 'In Stock';
            const isLowStock = med.stockStatus === 'Low Stock';

            return (
              <div
                key={med.id}
                className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs hover:shadow-md transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <span className="text-[11px] font-bold px-2 py-0.5 rounded bg-blue-50 text-blue-800 border border-blue-100 uppercase tracking-wider">
                      {med.category}
                    </span>

                    {/* Stock Status Badge */}
                    <div
                      className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold ${
                        isStockIn
                          ? 'bg-emerald-100 text-emerald-800'
                          : isLowStock
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-red-100 text-red-800'
                      }`}
                    >
                      {isStockIn ? (
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                      ) : isLowStock ? (
                        <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                      ) : (
                        <XCircle className="w-3.5 h-3.5 text-red-600" />
                      )}
                      <span>
                        {isStockIn ? t.stockIn : isLowStock ? t.stockLow : t.stockOut}
                      </span>
                    </div>
                  </div>

                  {/* Title & Marathi vernacular name */}
                  <h3 className="font-bold text-slate-900 text-lg leading-snug">
                    {med.genericName}
                  </h3>
                  <p className="text-xs font-semibold text-blue-900 mt-0.5">
                    {med.nameMr}
                  </p>

                  <div className="mt-3 bg-slate-50 p-3 rounded-lg border border-slate-100 text-xs space-y-1.5 text-slate-700">
                    <div className="flex justify-between">
                      <span className="text-slate-500">{language === 'mr' ? 'मात्रा व प्रकार:' : 'Form:'}</span>
                      <span className="font-medium text-slate-900">{med.dosageForm} ({med.strength})</span>
                    </div>

                    <div className="flex justify-between">
                      <span className="text-slate-500">{language === 'mr' ? 'उपलब्ध साठा:' : 'Available Stock:'}</span>
                      <span className="font-bold text-slate-900">{med.availableUnits.toLocaleString()} युनिट्स</span>
                    </div>

                    <div className="flex items-start justify-between gap-1 pt-1 border-t border-slate-200/60">
                      <span className="text-slate-500 shrink-0">{t.location}:</span>
                      <span className="font-semibold text-slate-800 text-right">{med.phcLocation}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-slate-500 mt-3">
                    <span>{t.batchNo} {med.batchNumber}</span>
                    <span>{t.expiryDate}: {med.expiryDate}</span>
                  </div>
                </div>

                {/* Free Govt Tag & Restock Alert */}
                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1 text-[11px] font-bold text-emerald-800">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{language === 'mr' ? 'मोफत सरकारी वाटप' : '100% Free Govt Supply'}</span>
                  </div>

                  {isLowStock || med.stockStatus === 'Out of Stock' ? (
                    <button
                      onClick={() => handleOpenAlert(med)}
                      className="flex items-center gap-1 text-xs font-semibold text-amber-800 hover:text-amber-950 bg-amber-50 hover:bg-amber-100 px-2.5 py-1.5 rounded-lg border border-amber-200 transition-colors"
                    >
                      <BellRing className="w-3.5 h-3.5 text-amber-600" />
                      <span>{language === 'mr' ? 'अलर्ट नोंदवा' : 'Notify Me'}</span>
                    </button>
                  ) : null}
                </div>
              </div>
            );
          })}
        </div>

        {/* Modal for SMS Restock Alert Subscription */}
        {alertModalMed && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
            <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 relative">
              <button
                onClick={() => setAlertModalMed(null)}
                className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 text-lg font-bold"
              >
                ✕
              </button>

              {!alertSubscribed ? (
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center">
                      <BellRing className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-bold text-slate-900 text-base">
                        {language === 'mr' ? 'औषध साठा अलर्ट सेवा' : 'Restock SMS Alert'}
                      </h3>
                      <p className="text-xs text-slate-500">
                        {alertModalMed.genericName}
                      </p>
                    </div>
                  </div>

                  <p className="text-xs text-slate-600">
                    {language === 'mr'
                      ? 'या औषधाचा साठा आपल्या तालुक्याच्या किंवा जवळच्या प्राथमिक आरोग्य केंद्रात दाखल होताच आपल्याला एसएमएस द्वारे मोफत कळवले जाईल.'
                      : 'You will receive an instant free SMS alert as soon as this medicine is dispatched and verified at your local PHC.'}
                  </p>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      {language === 'mr' ? 'आपला मोबाईल क्रमांक प्रविष्ट करा:' : 'Enter Mobile Number:'}
                    </label>
                    <input
                      type="tel"
                      value={subscriberPhone}
                      onChange={(e) => setSubscriberPhone(e.target.value)}
                      className="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm font-medium focus:ring-2 focus:ring-blue-600"
                    />
                  </div>

                  <button
                    onClick={() => setAlertSubscribed(true)}
                    className="w-full py-3 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-xl text-sm transition-all shadow-sm"
                  >
                    {language === 'mr' ? 'मोफत एसएमएस अलर्ट सक्रिय करा' : 'Activate Free Alert'}
                  </button>
                </div>
              ) : (
                <div className="text-center py-4 space-y-3">
                  <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto">
                    <Check className="w-6 h-6" />
                  </div>
                  <h4 className="font-bold text-slate-900 text-lg">
                    {language === 'mr' ? 'अलर्ट नोंदणी यशस्वी!' : 'Alert Registered!'}
                  </h4>
                  <p className="text-xs text-slate-600">
                    मोबाईल <strong>+91 {subscriberPhone}</strong> वर साठा दाखल होताच संदेश येईल.
                  </p>
                  <button
                    onClick={() => setAlertModalMed(null)}
                    className="w-full py-2 bg-blue-700 text-white rounded-lg text-xs font-bold mt-2"
                  >
                    बंद करा (Close)
                  </button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
