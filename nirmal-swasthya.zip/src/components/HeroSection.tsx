import React from 'react';
import { useApp } from '../context/AppContext';
import { MapPin, Video, Pill, ShieldCheck, Clock, Users, ArrowRight, HeartPulse, CheckCircle2 } from 'lucide-react';
import heroClinicImg from '../assets/images/hero_rural_clinic_1790169640661.jpg';

export const HeroSection: React.FC = () => {
  const { t, language, setActiveTab, dataSaver } = useApp();

  return (
    <section className="relative bg-gradient-to-b from-blue-50/80 via-white to-slate-50 pt-6 pb-12 sm:pb-16 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Text & Primary Call to Actions */}
          <div className="lg:col-span-7 space-y-6">
            {/* Government Assurance Badge */}
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-blue-100/80 border border-blue-200 text-blue-900 text-xs sm:text-sm font-semibold shadow-xs">
              <ShieldCheck className="w-4 h-4 text-blue-700 shrink-0" />
              <span>
                {language === 'mr'
                  ? 'महाराष्ट्र शासन · सार्वजनिक आरोग्य विभाग अधिकृत पोर्टल'
                  : language === 'hi'
                  ? 'महाराष्ट्र शासन · सार्वजनिक स्वास्थ्य विभाग अधिकृत पोर्टल'
                  : 'Govt of Maharashtra · Official Public Health Portal'}
              </span>
            </div>

            {/* Bold Headline (Prompt constraint) */}
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-[#0b2545] tracking-tight leading-tight">
              {t.heroHeadline}
            </h1>

            {/* Explanatory Subtitle */}
            <p className="text-base sm:text-lg text-slate-700 leading-relaxed max-w-2xl font-normal">
              {t.heroSub}
            </p>

            {/* Two Primary Action Buttons (Prompt constraint) */}
            <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 pt-2">
              <button
                onClick={() => setActiveTab('locator')}
                className="flex items-center justify-center gap-3 px-6 py-4 rounded-xl bg-[#0f3b6c] hover:bg-[#0b2545] text-white text-base sm:text-lg font-bold shadow-md hover:shadow-lg transition-all active:scale-[0.98] min-h-[56px]"
              >
                <MapPin className="w-6 h-6 text-emerald-300 shrink-0" />
                <span>{t.btnFindClinic}</span>
                <ArrowRight className="w-5 h-5 ml-1" />
              </button>

              <button
                onClick={() => setActiveTab('telemed')}
                className="flex items-center justify-center gap-3 px-6 py-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-base sm:text-lg font-bold shadow-md hover:shadow-lg transition-all active:scale-[0.98] min-h-[56px]"
              >
                <Video className="w-6 h-6 text-white shrink-0" />
                <span>{t.btnBookTelemed}</span>
                <span className="bg-emerald-800 text-emerald-100 text-xs px-2 py-0.5 rounded-full uppercase tracking-wider">
                  24x7 Free
                </span>
              </button>
            </div>

            {/* Third Fast Action: Medicine Stock Check */}
            <div className="pt-1">
              <button
                onClick={() => setActiveTab('medicines')}
                className="inline-flex items-center gap-2 text-sm font-semibold text-blue-800 hover:text-blue-950 underline decoration-blue-300 underline-offset-4"
              >
                <Pill className="w-4 h-4 text-blue-700" />
                <span>{t.btnCheckMeds} &rarr;</span>
              </button>
            </div>

            {/* Verified Public Health Guarantee Badges */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-4 border-t border-slate-200/80 text-xs sm:text-sm text-slate-700">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span className="font-medium">१००% मोफत औषधे (Free Drugs)</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span className="font-medium">२४x७ आपत्कालीन व प्रसूती</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span className="font-medium">कमी 2G/3G वर कॉल सुविधा</span>
              </div>
            </div>
          </div>

          {/* Authentic Documentary Visual Card */}
          <div className="lg:col-span-5">
            <div className="relative rounded-2xl overflow-hidden shadow-xl border-4 border-white bg-slate-900 group">
              {!dataSaver ? (
                <img
                  src={heroClinicImg}
                  alt="Rural Primary Health Center in Maharashtra"
                  className="w-full h-80 sm:h-96 object-cover transform group-hover:scale-102 transition-transform duration-700"
                />
              ) : (
                <div className="w-full h-72 bg-gradient-to-br from-blue-900 to-slate-800 flex flex-col items-center justify-center p-6 text-white text-center">
                  <HeartPulse className="w-12 h-12 text-emerald-400 mb-3" />
                  <p className="font-bold text-lg">डेटा सेव्हर मोड सक्रिय (Data Saver Active)</p>
                  <p className="text-xs text-slate-300 mt-1">
                    कमी बँडविड्थवर जलद कार्य करण्यासाठी फोटो तात्पुरता लपवला आहे.
                  </p>
                </div>
              )}

              {/* Floating Live Metrics Card */}
              <div className="absolute bottom-3 left-3 right-3 bg-white/95 backdrop-blur-md rounded-xl p-3 border border-slate-100 shadow-md text-slate-900">
                <div className="flex items-center justify-between border-b border-slate-100 pb-2 mb-2">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping"></span>
                    <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                      {language === 'mr' ? 'लाईव्ह आरोग्य नेटवर्क' : 'Live Health Network'}
                    </span>
                  </div>
                  <span className="text-[11px] font-semibold text-blue-700 bg-blue-50 px-2 py-0.5 rounded">
                    महाराष्ट्र राज्य
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <span className="text-slate-500 block text-[11px]">{t.liveStatsPhc}</span>
                    <span className="font-extrabold text-slate-900 text-sm">३,२४०+ केंद्रे</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[11px]">{t.liveStatsMeds}</span>
                    <span className="font-extrabold text-emerald-700 text-sm">९८.२% उपलब्ध</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 4 Big Pictorial Touch Cards for Elderly & Low-literacy Citizens */}
        <div className="mt-10 grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4">
          <button
            onClick={() => setActiveTab('locator')}
            className="bg-white hover:bg-blue-50/50 p-4 rounded-xl border border-slate-200 shadow-xs hover:shadow-md transition-all text-left flex flex-col justify-between group"
          >
            <div className="w-12 h-12 rounded-xl bg-blue-100 text-blue-800 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
              <MapPin className="w-6 h-6" />
            </div>
            <div>
              <span className="font-bold text-base text-slate-900 block leading-snug">
                {language === 'mr' ? 'दवाखाना शोधा' : language === 'hi' ? 'दवाखाना खोजें' : 'Find Clinic'}
              </span>
              <span className="text-xs text-slate-500 mt-0.5 block">
                {language === 'mr' ? 'जवळचे PHC व डॉक्टर' : 'Nearest PHC & Doctors'}
              </span>
            </div>
          </button>

          <button
            onClick={() => setActiveTab('telemed')}
            className="bg-white hover:bg-emerald-50/50 p-4 rounded-xl border border-slate-200 shadow-xs hover:shadow-md transition-all text-left flex flex-col justify-between group"
          >
            <div className="w-12 h-12 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
              <Video className="w-6 h-6" />
            </div>
            <div>
              <span className="font-bold text-base text-slate-900 block leading-snug">
                {language === 'mr' ? 'डॉक्टरांशी बोला' : language === 'hi' ? 'डॉक्टर से बात करें' : 'Talk to Doctor'}
              </span>
              <span className="text-xs text-slate-500 mt-0.5 block">
                {language === 'mr' ? 'मोफत टेलिफोन / व्हिडिओ' : 'Free 3G Tele-consultation'}
              </span>
            </div>
          </button>

          <button
            onClick={() => setActiveTab('medicines')}
            className="bg-white hover:bg-amber-50/50 p-4 rounded-xl border border-slate-200 shadow-xs hover:shadow-md transition-all text-left flex flex-col justify-between group"
          >
            <div className="w-12 h-12 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
              <Pill className="w-6 h-6" />
            </div>
            <div>
              <span className="font-bold text-base text-slate-900 block leading-snug">
                {language === 'mr' ? 'औषध साठा' : language === 'hi' ? 'दवा स्टॉक' : 'Medicine Stock'}
              </span>
              <span className="text-xs text-slate-500 mt-0.5 block">
                {language === 'mr' ? 'मोफत गोळ्या उपलब्ध आहेत का?' : 'Check real-time stock'}
              </span>
            </div>
          </button>

          <button
            onClick={() => setActiveTab('grievance')}
            className="bg-white hover:bg-purple-50/50 p-4 rounded-xl border border-slate-200 shadow-xs hover:shadow-md transition-all text-left flex flex-col justify-between group"
          >
            <div className="w-12 h-12 rounded-xl bg-purple-100 text-purple-800 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
              <HeartPulse className="w-6 h-6" />
            </div>
            <div>
              <span className="font-bold text-base text-slate-900 block leading-snug">
                {language === 'mr' ? 'तक्रार व अभिप्राय' : language === 'hi' ? 'शिकायत व रेटिंग' : 'Feedback & Grievance'}
              </span>
              <span className="text-xs text-slate-500 mt-0.5 block">
                {language === 'mr' ? 'स्वच्छता व डॉक्टर उपस्थिती' : 'Rate facility & staff'}
              </span>
            </div>
          </button>
        </div>
      </div>
    </section>
  );
};
