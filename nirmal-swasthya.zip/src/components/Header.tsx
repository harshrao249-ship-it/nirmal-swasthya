import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Phone, Wifi, WifiOff, Activity, ShieldCheck, Globe, Zap, Menu, X, Database } from 'lucide-react';
import { Language, NetworkMode } from '../types';

export const Header: React.FC = () => {
  const {
    language,
    setLanguage,
    t,
    networkMode,
    setNetworkMode,
    dataSaver,
    setDataSaver,
    textSize,
    setTextSize,
    activeTab,
    setActiveTab,
    pendingSyncCount,
  } = useApp();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showNetworkMenu, setShowNetworkMenu] = useState(false);

  const navItems = [
    { id: 'home', label: t.navHome },
    { id: 'locator', label: t.navLocator },
    { id: 'telemed', label: t.navTelemed },
    { id: 'medicines', label: t.navMedicine },
    { id: 'grievance', label: t.navGrievance },
    { id: 'asha-admin', label: t.navAshaAdmin },
  ] as const;

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
      {/* Official Government of Maharashtra Top Strip */}
      <div className="bg-[#0b2545] text-white text-xs px-4 py-1.5 flex flex-wrap items-center justify-between gap-2 border-b border-blue-950">
        <div className="flex items-center gap-2">
          {/* Government of Maharashtra Seal / Ashoka Emblem Representation */}
          <div className="w-5 h-5 rounded-full bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-[10px] font-bold text-amber-300">
            MH
          </div>
          <span className="font-medium tracking-wide">
            {t.deptTitle}, {t.govTitle}
          </span>
          <span className="text-slate-400 hidden sm:inline">|</span>
          <span className="text-slate-300 hidden sm:inline">National Health Mission (NHM)</span>
        </div>

        {/* Emergency Helplines Quick Dial */}
        <div className="flex items-center gap-3 text-[11px]">
          <a
            href="tel:108"
            className="flex items-center gap-1 font-semibold text-amber-300 hover:text-amber-200 transition-colors"
            title="Toll Free 24x7 Ambulance"
          >
            <Phone className="w-3 h-3 text-red-400 animate-pulse" />
            <span>{t.call108}</span>
          </a>
          <span className="text-slate-500">·</span>
          <a
            href="tel:104"
            className="flex items-center gap-1 text-slate-200 hover:text-white transition-colors hidden sm:flex"
            title="Toll Free Health Advice"
          >
            <span>{t.call104}</span>
          </a>
          <span className="text-slate-500 hidden sm:inline">·</span>

          {/* Simulated Network & Offline Toggle */}
          <div className="relative">
            <button
              onClick={() => setShowNetworkMenu(!showNetworkMenu)}
              className={`flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
                networkMode === 'offline'
                  ? 'bg-red-600 text-white animate-pulse'
                  : networkMode === 'slow-3g'
                  ? 'bg-amber-600 text-white'
                  : 'bg-emerald-800 text-emerald-100 hover:bg-emerald-700'
              }`}
              title="Click to toggle Network Simulation (Online/3G/Offline)"
            >
              {networkMode === 'offline' ? (
                <WifiOff className="w-3 h-3" />
              ) : (
                <Wifi className="w-3 h-3" />
              )}
              <span className="capitalize">{networkMode}</span>
              {pendingSyncCount > 0 && (
                <span className="bg-amber-400 text-slate-900 px-1 rounded-full text-[9px] font-bold">
                  {pendingSyncCount}
                </span>
              )}
            </button>

            {showNetworkMenu && (
              <div className="absolute right-0 top-full mt-1 w-48 bg-slate-900 border border-slate-700 rounded-lg shadow-xl p-2 z-50 text-slate-200 text-xs">
                <div className="font-semibold text-slate-400 mb-1 text-[10px] uppercase tracking-wider">
                  Network Simulator
                </div>
                <button
                  onClick={() => {
                    setNetworkMode('online');
                    setShowNetworkMenu(false);
                  }}
                  className={`w-full text-left px-2 py-1.5 rounded flex items-center justify-between ${
                    networkMode === 'online' ? 'bg-blue-600 text-white' : 'hover:bg-slate-800'
                  }`}
                >
                  <span>High-Speed Online</span>
                  <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                </button>
                <button
                  onClick={() => {
                    setNetworkMode('slow-3g');
                    setShowNetworkMenu(false);
                  }}
                  className={`w-full text-left px-2 py-1.5 rounded flex items-center justify-between ${
                    networkMode === 'slow-3g' ? 'bg-blue-600 text-white' : 'hover:bg-slate-800'
                  }`}
                >
                  <span>Rural 2G / Slow 3G</span>
                  <span className="w-2 h-2 rounded-full bg-amber-400"></span>
                </button>
                <button
                  onClick={() => {
                    setNetworkMode('offline');
                    setShowNetworkMenu(false);
                  }}
                  className={`w-full text-left px-2 py-1.5 rounded flex items-center justify-between ${
                    networkMode === 'offline' ? 'bg-red-600 text-white' : 'hover:bg-slate-800'
                  }`}
                >
                  <span>Simulate Offline Mode</span>
                  <span className="w-2 h-2 rounded-full bg-red-400"></span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Primary Top Bar Contract */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          {/* Zone 1: Single text element wordmark */}
          <button
            onClick={() => setActiveTab('home')}
            className="flex items-center gap-2.5 text-left focus:outline-none group"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#0f3b6c] to-[#1e5aa0] flex items-center justify-center text-white shadow-sm group-hover:scale-105 transition-transform">
              <Activity className="w-5 h-5 text-emerald-300" />
            </div>
            <div>
              <span className="text-xl font-bold tracking-tight text-[#0b2545] block leading-tight font-sans">
                Nirmal Swasthya
              </span>
              <span className="text-xs text-slate-500 font-medium block leading-none">
                निर्मल स्वास्थ्य · महाराष्ट्र शासन
              </span>
            </div>
          </button>

          {/* Zone 2: Clean 4-6 text navigation links */}
          <nav className="hidden lg:flex items-center gap-5 text-sm font-medium text-slate-700">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`pb-1 transition-colors whitespace-nowrap relative ${
                  activeTab === item.id
                    ? 'text-blue-700 font-semibold border-b-2 border-blue-700'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          {/* Zone 3: 1-2 primary actions + accessibility controls */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Low-Bandwidth Data Saver Toggle */}
            <button
              onClick={() => setDataSaver(!dataSaver)}
              className={`hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
                dataSaver
                  ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                  : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
              }`}
              title="Low Bandwidth Mode for 2G/3G connections"
            >
              <Zap className={`w-3.5 h-3.5 ${dataSaver ? 'text-emerald-600 fill-emerald-600' : 'text-slate-400'}`} />
              <span className="whitespace-nowrap">{t.dataSaver}</span>
            </button>

            {/* Language Switcher */}
            <div className="flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200 text-xs">
              {(['mr', 'hi', 'en'] as Language[]).map((lang) => (
                <button
                  key={lang}
                  onClick={() => setLanguage(lang)}
                  className={`px-2 py-1 rounded-md font-medium transition-all ${
                    language === lang
                      ? 'bg-[#0f3b6c] text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {lang === 'mr' ? 'मराठी' : lang === 'hi' ? 'हिंदी' : 'Eng'}
                </button>
              ))}
            </div>

            {/* Text Size Scale for Rural Accessibility */}
            <div className="hidden md:flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200 text-xs text-slate-700 font-semibold">
              <button
                onClick={() => setTextSize('normal')}
                className={`px-1.5 py-0.5 rounded text-[11px] ${textSize === 'normal' ? 'bg-white shadow-xs text-blue-900' : 'text-slate-500'}`}
                title="Standard Text Size"
              >
                A
              </button>
              <button
                onClick={() => setTextSize('large')}
                className={`px-1.5 py-0.5 rounded text-[13px] ${textSize === 'large' ? 'bg-white shadow-xs text-blue-900' : 'text-slate-500'}`}
                title="Large Text Size"
              >
                A+
              </button>
              <button
                onClick={() => setTextSize('xlarge')}
                className={`px-1.5 py-0.5 rounded text-[15px] ${textSize === 'xlarge' ? 'bg-white shadow-xs text-blue-900' : 'text-slate-500'}`}
                title="Extra Large Text Size"
              >
                A++
              </button>
            </div>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-lg text-slate-700 hover:bg-slate-100 focus:outline-none min-h-[44px] min-w-[44px] flex items-center justify-center"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white border-b border-slate-200 px-4 pt-2 pb-4 space-y-1 shadow-lg">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                setActiveTab(item.id);
                setMobileMenuOpen(false);
              }}
              className={`w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium flex items-center justify-between min-h-[44px] ${
                activeTab === item.id
                  ? 'bg-blue-50 text-blue-800 font-semibold'
                  : 'text-slate-700 hover:bg-slate-50'
              }`}
            >
              <span>{item.label}</span>
              {item.id === 'telemed' && (
                <span className="text-[10px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded font-medium">
                  24x7 Free
                </span>
              )}
            </button>
          ))}

          <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
            <button
              onClick={() => setDataSaver(!dataSaver)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium border ${
                dataSaver
                  ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                  : 'bg-slate-50 border-slate-200 text-slate-700'
              }`}
            >
              <Zap className={`w-3.5 h-3.5 ${dataSaver ? 'text-emerald-600' : 'text-slate-400'}`} />
              <span>{t.dataSaver}: {dataSaver ? 'ON' : 'OFF'}</span>
            </button>

            <div className="flex items-center gap-1 text-xs">
              <span className="text-slate-500 font-medium">Size:</span>
              <button
                onClick={() => setTextSize('normal')}
                className={`px-2 py-1 rounded border ${textSize === 'normal' ? 'bg-blue-600 text-white' : 'bg-slate-100'}`}
              >
                A
              </button>
              <button
                onClick={() => setTextSize('large')}
                className={`px-2 py-1 rounded border ${textSize === 'large' ? 'bg-blue-600 text-white' : 'bg-slate-100'}`}
              >
                A+
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
