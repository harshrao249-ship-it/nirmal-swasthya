import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { PHCFacility } from '../types';
import { MAHARASHTRA_DISTRICTS } from '../data/mockData';
import {
  MapPin,
  Clock,
  Phone,
  UserCheck,
  Stethoscope,
  Ambulance,
  Baby,
  Star,
  Search,
  Filter,
  Navigation,
  CheckCircle,
  AlertCircle,
  ExternalLink,
} from 'lucide-react';

export const FacilityLocator: React.FC = () => {
  const { facilities, language, t, setSelectedFacility, setActiveTab } = useApp();
  const [selectedDistrict, setSelectedDistrict] = useState<string>('All Districts');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filter24x7Only, setFilter24x7Only] = useState<boolean>(false);
  const [filterAmbulanceOnly, setFilterAmbulanceOnly] = useState<boolean>(false);
  const [activeFacilityId, setActiveFacilityId] = useState<string>(facilities[0]?.id || '');
  const [showAppointmentModal, setShowAppointmentModal] = useState<PHCFacility | null>(null);
  const [appointmentBooked, setAppointmentBooked] = useState<boolean>(false);

  // Filter facilities
  const filteredFacilities = facilities.filter((fac) => {
    if (selectedDistrict !== 'All Districts' && !fac.district.toLowerCase().includes(selectedDistrict.toLowerCase().replace(' rural', ''))) {
      return false;
    }
    if (filter24x7Only && !fac.deliveryFacility24x7) return false;
    if (filterAmbulanceOnly && !fac.ambulanceAvailable) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = fac.name.toLowerCase().includes(q) || fac.nameMr.toLowerCase().includes(q) || fac.taluka.toLowerCase().includes(q);
      const matchDoctor = fac.doctors.some((d) => d.name.toLowerCase().includes(q) || d.specialty.toLowerCase().includes(q));
      if (!matchName && !matchDoctor) return false;
    }
    return true;
  });

  const currentActiveFacility = facilities.find((f) => f.id === activeFacilityId) || filteredFacilities[0] || facilities[0];

  const handleBookToken = (fac: PHCFacility) => {
    setShowAppointmentModal(fac);
    setAppointmentBooked(false);
  };

  return (
    <section className="py-10 bg-slate-50 border-b border-slate-200" id="facility-locator">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="mb-8 text-center sm:text-left">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-100 text-blue-900 text-xs font-semibold mb-2">
            <MapPin className="w-3.5 h-3.5 text-blue-700" />
            <span>{language === 'mr' ? 'आरोग्य सुविधा शोधक' : 'Rural Health Infrastructure'}</span>
          </div>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-[#0b2545] tracking-tight">
            {t.locatorTitle}
          </h2>
          <p className="text-slate-600 mt-2 text-sm sm:text-base max-w-3xl">
            {t.locatorSubtitle}
          </p>
        </div>

        {/* Filter & Search Bar */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm mb-6 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
            {/* Search Input */}
            <div className="sm:col-span-6 relative">
              <Search className="w-5 h-5 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={
                  language === 'mr'
                    ? 'आरोग्य केंद्र, तालुका किंवा डॉक्टरांचे नाव शोधा...'
                    : 'Search PHC name, taluka, or doctor...'
                }
                className="w-full pl-10 pr-4 py-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-blue-600 focus:border-blue-600 text-sm font-medium text-slate-800"
              />
            </div>

            {/* District Selector */}
            <div className="sm:col-span-6 flex gap-2">
              <select
                value={selectedDistrict}
                onChange={(e) => setSelectedDistrict(e.target.value)}
                className="w-full py-3 px-3.5 rounded-lg border border-slate-300 bg-white focus:ring-2 focus:ring-blue-600 text-sm font-medium text-slate-800"
              >
                {MAHARASHTRA_DISTRICTS.map((d) => (
                  <option key={d} value={d}>
                    {d === 'All Districts' && language === 'mr' ? 'सर्व जिल्हे (All Districts)' : d}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Quick Category Filters */}
          <div className="flex flex-wrap items-center gap-2 pt-1 text-xs">
            <span className="text-slate-500 font-semibold flex items-center gap-1">
              <Filter className="w-3.5 h-3.5" />
              {language === 'mr' ? 'जलद फिल्टर:' : 'Quick Filters:'}
            </span>

            <button
              onClick={() => setFilter24x7Only(!filter24x7Only)}
              className={`px-3 py-1.5 rounded-lg font-medium border transition-colors flex items-center gap-1.5 ${
                filter24x7Only
                  ? 'bg-blue-700 text-white border-blue-800'
                  : 'bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200'
              }`}
            >
              <Baby className="w-3.5 h-3.5" />
              <span>{t.filter24x7}</span>
            </button>

            <button
              onClick={() => setFilterAmbulanceOnly(!filterAmbulanceOnly)}
              className={`px-3 py-1.5 rounded-lg font-medium border transition-colors flex items-center gap-1.5 ${
                filterAmbulanceOnly
                  ? 'bg-blue-700 text-white border-blue-800'
                  : 'bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200'
              }`}
            >
              <Ambulance className="w-3.5 h-3.5" />
              <span>{t.filterAmbulance}</span>
            </button>

            {(filter24x7Only || filterAmbulanceOnly || searchQuery || selectedDistrict !== 'All Districts') && (
              <button
                onClick={() => {
                  setFilter24x7Only(false);
                  setFilterAmbulanceOnly(false);
                  setSearchQuery('');
                  setSelectedDistrict('All Districts');
                }}
                className="text-red-600 hover:text-red-800 font-semibold underline ml-2"
              >
                {language === 'mr' ? 'फिल्टर काढा' : 'Reset'}
              </button>
            )}
          </div>
        </div>

        {/* 2-Column Responsive Layout: Facility List & Interactive Map Visualizer */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left: Interactive Facility Cards */}
          <div className="lg:col-span-7 space-y-4 max-h-[640px] overflow-y-auto pr-1">
            {filteredFacilities.length === 0 ? (
              <div className="bg-white rounded-xl p-8 text-center border border-slate-200">
                <AlertCircle className="w-10 h-10 text-amber-500 mx-auto mb-2" />
                <h3 className="font-bold text-slate-800 text-lg">कोणतेही आरोग्य केंद्र सापडले नाही</h3>
                <p className="text-sm text-slate-500 mt-1">
                  कृपया वेगळा जिल्हा किंवा शोध निकष वापरून तपासा.
                </p>
              </div>
            ) : (
              filteredFacilities.map((fac) => {
                const isSelected = fac.id === currentActiveFacility?.id;
                return (
                  <div
                    key={fac.id}
                    onClick={() => setActiveFacilityId(fac.id)}
                    className={`p-4 sm:p-5 rounded-xl border transition-all cursor-pointer bg-white text-left ${
                      isSelected
                        ? 'border-blue-600 shadow-md ring-2 ring-blue-500/20'
                        : 'border-slate-200 hover:border-slate-300 hover:shadow-xs'
                    }`}
                  >
                    <div className="flex flex-wrap items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-blue-100 text-blue-800">
                            {fac.type}
                          </span>
                          <span className="text-xs text-slate-500 font-medium">
                            {fac.taluka}, {fac.district}
                          </span>
                        </div>
                        <h3 className="text-lg sm:text-xl font-bold text-slate-900 mt-1">
                          {language === 'mr' ? fac.nameMr : fac.name}
                        </h3>
                      </div>

                      {/* Distance Badge */}
                      <div className="flex items-center gap-1 bg-emerald-50 text-emerald-800 px-2.5 py-1 rounded-lg text-xs font-bold border border-emerald-200 shrink-0">
                        <Navigation className="w-3.5 h-3.5 text-emerald-600" />
                        <span>{fac.distanceKm} km {language === 'mr' ? 'अंतरावर' : 'away'}</span>
                      </div>
                    </div>

                    {/* Address & Timings */}
                    <p className="text-xs sm:text-sm text-slate-600 mt-2 flex items-start gap-1.5">
                      <MapPin className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
                      <span>{fac.address}</span>
                    </p>

                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mt-3 pt-3 border-t border-slate-100 text-xs">
                      <div>
                        <span className="text-slate-500 block text-[11px]">{t.opdHours}</span>
                        <span className="font-semibold text-slate-800 block truncate">{fac.operatingHours}</span>
                      </div>
                      <div>
                        <span className="text-slate-500 block text-[11px]">{t.waitTime}</span>
                        <span className="font-bold text-amber-700">~{fac.currentWaitMinutes} mins</span>
                      </div>
                      <div className="col-span-2 sm:col-span-1">
                        <span className="text-slate-500 block text-[11px]">{t.bedsAvailable}</span>
                        <span className="font-semibold text-emerald-700">
                          {fac.availableBeds} / {fac.totalBeds} Beds
                        </span>
                      </div>
                    </div>

                    {/* Doctors on Duty Today */}
                    <div className="mt-3 bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                      <div className="text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1 flex items-center gap-1">
                        <Stethoscope className="w-3.5 h-3.5 text-blue-600" />
                        <span>{t.availableDoctors} ({fac.doctors.filter(d => d.availableToday).length}):</span>
                      </div>
                      <div className="space-y-1">
                        {fac.doctors.map((doc) => (
                          <div key={doc.id} className="text-xs flex items-center justify-between text-slate-800">
                            <span className="font-medium">{doc.name}</span>
                            <span className="text-[11px] text-slate-500 italic truncate max-w-[180px]">
                              {doc.specialty}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Facility Action Buttons (Large touch targets) */}
                    <div className="flex flex-wrap items-center gap-2 mt-4 pt-2">
                      <a
                        href={`tel:${fac.contactNumber.replace(/\s+/g, '')}`}
                        className="flex-1 min-w-[130px] flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs sm:text-sm font-semibold transition-colors min-h-[44px]"
                      >
                        <Phone className="w-4 h-4 text-emerald-700" />
                        <span>{fac.contactNumber}</span>
                      </a>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleBookToken(fac);
                        }}
                        className="flex-1 min-w-[150px] flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-lg bg-[#0f3b6c] hover:bg-[#0b2545] text-white text-xs sm:text-sm font-semibold transition-colors min-h-[44px]"
                      >
                        <UserCheck className="w-4 h-4 text-emerald-300" />
                        <span>{t.bookAppointment}</span>
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Right: Interactive Simulated Map & Facility Detail Panel */}
          <div className="lg:col-span-5 space-y-4">
            {/* Interactive Simulated Map Box */}
            <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-sm">
              <div className="bg-[#0b2545] text-white px-4 py-2.5 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-emerald-400" />
                  <span className="font-bold text-sm">
                    {language === 'mr' ? 'स्थानिक नकाशा दृश्य (Geo Map)' : 'PHC Geographic View'}
                  </span>
                </div>
                <span className="text-xs bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded font-mono">
                  GPS Active
                </span>
              </div>

              {/* Map Canvas / Visualizer with interactive pins */}
              <div className="relative h-64 bg-slate-100 border-b border-slate-200 overflow-hidden flex items-center justify-center">
                {/* SVG Topography & District Grid Simulation */}
                <svg className="absolute inset-0 w-full h-full opacity-40" xmlns="http://www.w3.org/2000/svg">
                  <defs>
                    <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                      <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#94a3b8" strokeWidth="0.8" />
                    </pattern>
                  </defs>
                  <rect width="100%" height="100%" fill="url(#grid)" />
                  {/* Subtle curves representing Sahyadri hills & rural roads */}
                  <path d="M 0 120 Q 150 70 300 180 T 500 130" fill="none" stroke="#cbd5e1" strokeWidth="3" />
                  <path d="M 50 250 Q 200 140 450 220" fill="none" stroke="#94a3b8" strokeWidth="2" strokeDasharray="4 4" />
                </svg>

                {/* Facility Pins positioned dynamically */}
                {facilities.map((f, idx) => {
                  const isSelected = f.id === currentActiveFacility?.id;
                  // Static simulated coordinates on the map view
                  const offsets = [
                    { top: '35%', left: '42%' },
                    { top: '20%', left: '25%' },
                    { top: '65%', left: '78%' },
                    { top: '30%', left: '32%' },
                    { top: '18%', left: '55%' },
                    { top: '75%', left: '28%' },
                  ];
                  const pos = offsets[idx % offsets.length];

                  return (
                    <button
                      key={f.id}
                      onClick={() => setActiveFacilityId(f.id)}
                      style={{ top: pos.top, left: pos.left }}
                      className={`absolute -translate-x-1/2 -translate-y-1/2 group transition-all z-10 ${
                        isSelected ? 'scale-125 z-20' : 'hover:scale-110'
                      }`}
                      title={f.name}
                    >
                      <div
                        className={`w-9 h-9 rounded-full flex items-center justify-center shadow-lg border-2 ${
                          isSelected
                            ? 'bg-blue-700 text-white border-white ring-4 ring-blue-400/40 animate-bounce'
                            : 'bg-white text-blue-900 border-blue-700 hover:bg-blue-50'
                        }`}
                      >
                        <MapPin className="w-5 h-5" />
                      </div>
                      <span className="absolute left-1/2 -translate-x-1/2 top-full mt-1 bg-slate-900 text-white text-[10px] font-bold px-1.5 py-0.5 rounded whitespace-nowrap shadow-md pointer-events-none">
                        {f.distanceKm} km
                      </span>
                    </button>
                  );
                })}

                {/* Patient "You are here" simulated pin */}
                <div className="absolute top-[48%] left-[45%] -translate-x-1/2 -translate-y-1/2 z-10 flex flex-col items-center pointer-events-none">
                  <div className="w-4 h-4 bg-emerald-500 rounded-full border-2 border-white ring-4 ring-emerald-300/60 animate-ping"></div>
                  <span className="mt-1 bg-emerald-800 text-white text-[9px] font-bold px-1.5 rounded">
                    {language === 'mr' ? 'आपले स्थान' : 'Your Location'}
                  </span>
                </div>
              </div>

              {/* Active Selected Facility Snapshot */}
              {currentActiveFacility && (
                <div className="p-4 bg-white space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-xs font-bold text-blue-700 uppercase">
                        {currentActiveFacility.type} · {currentActiveFacility.district}
                      </span>
                      <h4 className="font-bold text-slate-900 text-base leading-snug">
                        {language === 'mr' ? currentActiveFacility.nameMr : currentActiveFacility.name}
                      </h4>
                    </div>
                    <div className="flex items-center gap-1 text-amber-500 text-xs font-bold bg-amber-50 px-2 py-1 rounded">
                      <Star className="w-3.5 h-3.5 fill-amber-400" />
                      <span>{currentActiveFacility.cleanlinessScore} / 5</span>
                    </div>
                  </div>

                  <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 text-xs space-y-1.5">
                    <div className="flex justify-between text-slate-700">
                      <span className="text-slate-500">{language === 'mr' ? 'मोफत लॅब तपासण्या:' : 'Free Lab Tests:'}</span>
                      <span className="font-semibold text-slate-900">{currentActiveFacility.labTestsCount} प्रकारच्या चाचण्या उपलब्ध</span>
                    </div>
                    <div className="flex justify-between text-slate-700">
                      <span className="text-slate-500">{language === 'mr' ? 'रुग्णवाहिका (Ambulance):' : 'Ambulance:'}</span>
                      <span className="font-semibold text-emerald-700">
                        {currentActiveFacility.ambulanceAvailable ? '२४ तास हजर (On Duty)' : 'मागणीनुसार'}
                      </span>
                    </div>
                    <div className="flex justify-between text-slate-700">
                      <span className="text-slate-500">{language === 'mr' ? 'प्रसूती कक्ष:' : 'Labor Room:'}</span>
                      <span className="font-semibold text-emerald-700">
                        {currentActiveFacility.deliveryFacility24x7 ? '२४x७ सक्रिय' : 'दिवसपाळी'}
                      </span>
                    </div>
                  </div>

                  <div className="flex gap-2 pt-1">
                    <a
                      href={`https://maps.google.com/?q=${currentActiveFacility.coordinates.lat},${currentActiveFacility.coordinates.lng}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 flex items-center justify-center gap-1.5 py-2.5 px-3 bg-slate-100 hover:bg-slate-200 rounded-lg text-slate-800 text-xs font-bold transition-colors"
                    >
                      <Navigation className="w-3.5 h-3.5 text-blue-700" />
                      <span>{language === 'mr' ? 'गुगल मॅपवर दिशा बघा' : 'Get Directions'}</span>
                    </a>

                    <button
                      onClick={() => handleBookToken(currentActiveFacility)}
                      className="flex-1 flex items-center justify-center gap-1.5 py-2.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition-colors"
                    >
                      <CheckCircle className="w-3.5 h-3.5" />
                      <span>{language === 'mr' ? 'ओपीडी टोकन मिळवा' : 'Get OPD Token'}</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Modal: OPD Token / Appointment Confirmation */}
        {showAppointmentModal && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
            <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 relative">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
                    OPD
                  </div>
                  <h3 className="font-bold text-slate-900 text-lg">
                    {language === 'mr' ? 'ओपीडी टोकन आरक्षण' : 'OPD Token Slip'}
                  </h3>
                </div>
                <button
                  onClick={() => setShowAppointmentModal(null)}
                  className="text-slate-400 hover:text-slate-600 p-1 font-bold text-lg"
                >
                  ✕
                </button>
              </div>

              {!appointmentBooked ? (
                <div className="space-y-4 text-sm text-slate-700">
                  <div className="bg-blue-50 p-3 rounded-lg border border-blue-100">
                    <span className="text-xs text-blue-700 font-bold block uppercase">
                      {showAppointmentModal.type}
                    </span>
                    <h4 className="font-bold text-slate-900 text-base">
                      {language === 'mr' ? showAppointmentModal.nameMr : showAppointmentModal.name}
                    </h4>
                    <p className="text-xs text-slate-600 mt-1">{showAppointmentModal.address}</p>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      {t.patientName} *
                    </label>
                    <input
                      type="text"
                      defaultValue="रमेश सखाराम जाधव"
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm font-medium focus:ring-2 focus:ring-blue-600"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        {t.patientAge} *
                      </label>
                      <input
                        type="number"
                        defaultValue="48"
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm font-medium"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        {t.phone} *
                      </label>
                      <input
                        type="tel"
                        defaultValue="9823012345"
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm font-medium"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      {language === 'mr' ? 'तपासणी विभाग निवडा' : 'Select Department'}
                    </label>
                    <select className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm bg-white font-medium">
                      <option>General Medicine OPD (सामान्य ओपीडी)</option>
                      <option>Maternal ANC & Delivery (माता व बाल संगोपन)</option>
                      <option>Pediatric / Child Care (बालरोग विभाग)</option>
                      <option>NCD Clinic - Sugar/BP (मधुमेह व रक्तदाब)</option>
                    </select>
                  </div>

                  <button
                    onClick={() => setAppointmentBooked(true)}
                    className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-base shadow-md transition-all mt-2 min-h-[48px]"
                  >
                    {language === 'mr' ? 'मोफत टोकन जारी करा' : 'Generate Free Token'}
                  </button>
                </div>
              ) : (
                <div className="text-center py-4 space-y-4">
                  <div className="w-16 h-16 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto">
                    <CheckCircle className="w-10 h-10" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-emerald-700 uppercase tracking-wider">
                      टोकन यशस्वीरित्या बुक झाले!
                    </span>
                    <h3 className="text-3xl font-extrabold text-slate-900 mt-1">#OPD-28</h3>
                    <p className="text-xs text-slate-500 mt-1">
                      अंदाजे तपासणी वेळ: आज सकाळी ११:१५ वाजता
                    </p>
                  </div>

                  <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 text-left text-xs space-y-1 text-slate-700">
                    <div><strong>आरोग्य केंद्र:</strong> {showAppointmentModal.name}</div>
                    <div><strong>रुग्ण:</strong> रमेश सखाराम जाधव (वय ४८)</div>
                    <div><strong>शुल्क:</strong> ₹०.०० (महाराष्ट्र शासन मोफत उपचार)</div>
                  </div>

                  <p className="text-[11px] text-slate-500">
                    एसएमएस आपल्या नोंदणीकृत मोबाईलवर पाठवला आहे. आरोग्य केंद्रात जाताना थेट ओपीडी खिडकीवर हा क्रमांक दाखवा.
                  </p>

                  <button
                    onClick={() => setShowAppointmentModal(null)}
                    className="w-full py-2.5 bg-blue-700 text-white rounded-lg font-bold text-sm"
                  >
                    पूर्ण झाले (Done)
                  </button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
